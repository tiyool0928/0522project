﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sellbuy_Winform
{
    public class Buyer
    {
        public string Id { get; set; }
        public string Password { get; set; }
        public int Money { get; set; }

        public Buyer(string Id, string Password)
        {
            this.Id = Id;
            this.Password = Password;
            Money = 0;
        }
    }
}
