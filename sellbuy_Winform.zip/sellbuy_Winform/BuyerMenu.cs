﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class BuyerMenu : Form
    {
        Buyer buyer;
        Seller seller;
        public BuyerMenu(Buyer buyer)
        {
            InitializeComponent();
            this.buyer = buyer;
        }

        private void BuyerMenu_Load(object sender, EventArgs e)
        {
            WelcomeUser.Text = string.Format("{0}님의 잔액", buyer.Id);
            dataGridView1.DataSource = ProgramManager.sellers;
            dataGridView1.CurrentCellChanged += dataGridView1_CurrentCellChanged;
            txtMoney.Text = Convert.ToString(buyer.Money);
        }

        private void dataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {
            Seller selectedSeller = dataGridView1.CurrentRow.DataBoundItem as Seller;
            txtSellerInfor.Text = selectedSeller.Id;
            seller = selectedSeller;
        }

        private void WelcomeUser_Click(object sender, EventArgs e)
        {

        }

        private void MoneyCharge_Click(object sender, EventArgs e)
        {
            new MoneyCharge(buyer).ShowDialog();
        }

        private void PurchaseBtn_Click(object sender, EventArgs e)
        {
            new Purchase(seller, buyer).ShowDialog();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void Tostart_Click(object sender, EventArgs e)
        {
            new Form1().ShowDialog();
        }
    }
}
