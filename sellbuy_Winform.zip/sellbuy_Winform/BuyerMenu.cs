﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class BuyerMenu : Form
    {
        public BuyerMenu(Buyer buyer)
        {
            InitializeComponent();
        }

        private void BuyerMenu_Load(object sender, EventArgs e)
        {

        }

        private void WelcomeUser_Click(object sender, EventArgs e)
        {

        }
    }
}
