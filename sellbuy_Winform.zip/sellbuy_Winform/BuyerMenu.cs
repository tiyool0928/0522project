﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class BuyerMenu : Form
    {
        Buyer buyer;
        public BuyerMenu(Buyer buyer)
        {
            InitializeComponent();
            this.buyer = buyer;
        }

        private void BuyerMenu_Load(object sender, EventArgs e)
        {
            WelcomeUser.Text = string.Format("{0}님의 잔액", buyer.Id);
        }

        private void WelcomeUser_Click(object sender, EventArgs e)
        {

        }
    }
}
