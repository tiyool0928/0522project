﻿namespace sellbuy_Winform
{
    partial class SellerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeUser = new System.Windows.Forms.Label();
            this.PpriceBtn = new System.Windows.Forms.Button();
            this.ExitBtn = new System.Windows.Forms.Button();
            this.PnumBtn = new System.Windows.Forms.Button();
            this.txtPprice = new System.Windows.Forms.TextBox();
            this.txtPnum = new System.Windows.Forms.TextBox();
            this.PpriceCharge = new System.Windows.Forms.Button();
            this.PnumCharge = new System.Windows.Forms.Button();
            this.MoneyBtn = new System.Windows.Forms.Button();
            this.txtMoney = new System.Windows.Forms.TextBox();
            this.MoneySettle = new System.Windows.Forms.Button();
            this.Tostart = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WelcomeUser
            // 
            this.WelcomeUser.AutoSize = true;
            this.WelcomeUser.Font = new System.Drawing.Font("맑은 고딕", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.WelcomeUser.Location = new System.Drawing.Point(292, 71);
            this.WelcomeUser.Name = "WelcomeUser";
            this.WelcomeUser.Size = new System.Drawing.Size(201, 32);
            this.WelcomeUser.TabIndex = 0;
            this.WelcomeUser.Text = "환영합니다 ~~님";
            this.WelcomeUser.Click += new System.EventHandler(this.WelcomeUser_Click);
            // 
            // PpriceBtn
            // 
            this.PpriceBtn.Location = new System.Drawing.Point(218, 230);
            this.PpriceBtn.Name = "PpriceBtn";
            this.PpriceBtn.Size = new System.Drawing.Size(206, 46);
            this.PpriceBtn.TabIndex = 6;
            this.PpriceBtn.Text = "물품 가격 확인";
            this.PpriceBtn.UseVisualStyleBackColor = true;
            this.PpriceBtn.Click += new System.EventHandler(this.PpriceBtn_Click);
            // 
            // ExitBtn
            // 
            this.ExitBtn.Location = new System.Drawing.Point(218, 362);
            this.ExitBtn.Name = "ExitBtn";
            this.ExitBtn.Size = new System.Drawing.Size(206, 46);
            this.ExitBtn.TabIndex = 5;
            this.ExitBtn.Text = "프로그램 종료";
            this.ExitBtn.UseVisualStyleBackColor = true;
            this.ExitBtn.Click += new System.EventHandler(this.ExitBtn_Click);
            // 
            // PnumBtn
            // 
            this.PnumBtn.Location = new System.Drawing.Point(218, 163);
            this.PnumBtn.Name = "PnumBtn";
            this.PnumBtn.Size = new System.Drawing.Size(206, 46);
            this.PnumBtn.TabIndex = 4;
            this.PnumBtn.Text = "물품 개수 확인";
            this.PnumBtn.UseVisualStyleBackColor = true;
            this.PnumBtn.Click += new System.EventHandler(this.PnumBtn_Click);
            // 
            // txtPprice
            // 
            this.txtPprice.Location = new System.Drawing.Point(449, 244);
            this.txtPprice.Name = "txtPprice";
            this.txtPprice.Size = new System.Drawing.Size(180, 21);
            this.txtPprice.TabIndex = 19;
            // 
            // txtPnum
            // 
            this.txtPnum.Location = new System.Drawing.Point(449, 177);
            this.txtPnum.Name = "txtPnum";
            this.txtPnum.Size = new System.Drawing.Size(180, 21);
            this.txtPnum.TabIndex = 18;
            // 
            // PpriceCharge
            // 
            this.PpriceCharge.Location = new System.Drawing.Point(635, 237);
            this.PpriceCharge.Name = "PpriceCharge";
            this.PpriceCharge.Size = new System.Drawing.Size(53, 32);
            this.PpriceCharge.TabIndex = 23;
            this.PpriceCharge.Text = "재책정";
            this.PpriceCharge.UseVisualStyleBackColor = true;
            this.PpriceCharge.Click += new System.EventHandler(this.PpriceCharge_Click);
            // 
            // PnumCharge
            // 
            this.PnumCharge.Location = new System.Drawing.Point(635, 170);
            this.PnumCharge.Name = "PnumCharge";
            this.PnumCharge.Size = new System.Drawing.Size(53, 32);
            this.PnumCharge.TabIndex = 22;
            this.PnumCharge.Text = "충전";
            this.PnumCharge.UseVisualStyleBackColor = true;
            this.PnumCharge.Click += new System.EventHandler(this.PnumCharge_Click);
            // 
            // MoneyBtn
            // 
            this.MoneyBtn.Location = new System.Drawing.Point(218, 296);
            this.MoneyBtn.Name = "MoneyBtn";
            this.MoneyBtn.Size = new System.Drawing.Size(206, 46);
            this.MoneyBtn.TabIndex = 24;
            this.MoneyBtn.Text = "매출 조회";
            this.MoneyBtn.UseVisualStyleBackColor = true;
            this.MoneyBtn.Click += new System.EventHandler(this.MoneyBtn_Click);
            // 
            // txtMoney
            // 
            this.txtMoney.Location = new System.Drawing.Point(449, 310);
            this.txtMoney.Name = "txtMoney";
            this.txtMoney.Size = new System.Drawing.Size(180, 21);
            this.txtMoney.TabIndex = 25;
            // 
            // MoneySettle
            // 
            this.MoneySettle.Location = new System.Drawing.Point(635, 303);
            this.MoneySettle.Name = "MoneySettle";
            this.MoneySettle.Size = new System.Drawing.Size(53, 32);
            this.MoneySettle.TabIndex = 26;
            this.MoneySettle.Text = "정산";
            this.MoneySettle.UseVisualStyleBackColor = true;
            this.MoneySettle.Click += new System.EventHandler(this.MoneySettle_Click);
            // 
            // Tostart
            // 
            this.Tostart.Location = new System.Drawing.Point(449, 362);
            this.Tostart.Name = "Tostart";
            this.Tostart.Size = new System.Drawing.Size(212, 46);
            this.Tostart.TabIndex = 30;
            this.Tostart.Text = "시작 화면으로";
            this.Tostart.UseVisualStyleBackColor = true;
            this.Tostart.Click += new System.EventHandler(this.Tostart_Click);
            // 
            // SellerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Tostart);
            this.Controls.Add(this.MoneySettle);
            this.Controls.Add(this.txtMoney);
            this.Controls.Add(this.MoneyBtn);
            this.Controls.Add(this.PpriceCharge);
            this.Controls.Add(this.PnumCharge);
            this.Controls.Add(this.txtPprice);
            this.Controls.Add(this.txtPnum);
            this.Controls.Add(this.PpriceBtn);
            this.Controls.Add(this.ExitBtn);
            this.Controls.Add(this.PnumBtn);
            this.Controls.Add(this.WelcomeUser);
            this.Name = "SellerMenu";
            this.Text = "SellerMenu";
            this.Load += new System.EventHandler(this.SellerMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeUser;
        private System.Windows.Forms.Button PpriceBtn;
        private System.Windows.Forms.Button ExitBtn;
        private System.Windows.Forms.Button PnumBtn;
        private System.Windows.Forms.TextBox txtPprice;
        private System.Windows.Forms.TextBox txtPnum;
        private System.Windows.Forms.Button PpriceCharge;
        private System.Windows.Forms.Button PnumCharge;
        private System.Windows.Forms.Button MoneyBtn;
        private System.Windows.Forms.TextBox txtMoney;
        private System.Windows.Forms.Button MoneySettle;
        private System.Windows.Forms.Button Tostart;
    }
}