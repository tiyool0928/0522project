﻿namespace sellbuy_Winform
{
    partial class Purchase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeUser = new System.Windows.Forms.Label();
            this.PurchaseBtn = new System.Windows.Forms.Button();
            this.Pnum = new System.Windows.Forms.TextBox();
            this.OkBtn = new System.Windows.Forms.Button();
            this.txtAllprice = new System.Windows.Forms.TextBox();
            this.priceLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CancleBtn = new System.Windows.Forms.Button();
            this.won = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // WelcomeUser
            // 
            this.WelcomeUser.AutoSize = true;
            this.WelcomeUser.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.WelcomeUser.Location = new System.Drawing.Point(110, 61);
            this.WelcomeUser.Name = "WelcomeUser";
            this.WelcomeUser.Size = new System.Drawing.Size(218, 17);
            this.WelcomeUser.TabIndex = 2;
            this.WelcomeUser.Text = "구매할 물품의 개수를 입력해주세요";
            // 
            // PurchaseBtn
            // 
            this.PurchaseBtn.Location = new System.Drawing.Point(333, 105);
            this.PurchaseBtn.Name = "PurchaseBtn";
            this.PurchaseBtn.Size = new System.Drawing.Size(53, 32);
            this.PurchaseBtn.TabIndex = 29;
            this.PurchaseBtn.Text = "구매";
            this.PurchaseBtn.UseVisualStyleBackColor = true;
            this.PurchaseBtn.Click += new System.EventHandler(this.PurchaseBtn_Click);
            // 
            // Pnum
            // 
            this.Pnum.Location = new System.Drawing.Point(113, 112);
            this.Pnum.Name = "Pnum";
            this.Pnum.Size = new System.Drawing.Size(150, 21);
            this.Pnum.TabIndex = 28;
            // 
            // OkBtn
            // 
            this.OkBtn.Location = new System.Drawing.Point(333, 150);
            this.OkBtn.Name = "OkBtn";
            this.OkBtn.Size = new System.Drawing.Size(53, 32);
            this.OkBtn.TabIndex = 31;
            this.OkBtn.Text = "확인";
            this.OkBtn.UseVisualStyleBackColor = true;
            this.OkBtn.Click += new System.EventHandler(this.OkBtn_Click);
            // 
            // txtAllprice
            // 
            this.txtAllprice.Location = new System.Drawing.Point(113, 157);
            this.txtAllprice.Name = "txtAllprice";
            this.txtAllprice.Size = new System.Drawing.Size(150, 21);
            this.txtAllprice.TabIndex = 30;
            // 
            // priceLabel
            // 
            this.priceLabel.AutoSize = true;
            this.priceLabel.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.priceLabel.Location = new System.Drawing.Point(55, 157);
            this.priceLabel.Name = "priceLabel";
            this.priceLabel.Size = new System.Drawing.Size(52, 17);
            this.priceLabel.TabIndex = 32;
            this.priceLabel.Text = "총 가격";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(42, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 33;
            this.label2.Text = "물품 개수";
            // 
            // CancleBtn
            // 
            this.CancleBtn.Location = new System.Drawing.Point(134, 184);
            this.CancleBtn.Name = "CancleBtn";
            this.CancleBtn.Size = new System.Drawing.Size(169, 32);
            this.CancleBtn.TabIndex = 34;
            this.CancleBtn.Text = "뒤로";
            this.CancleBtn.UseVisualStyleBackColor = true;
            this.CancleBtn.Click += new System.EventHandler(this.CancleBtn_Click);
            // 
            // won
            // 
            this.won.AutoSize = true;
            this.won.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.won.Location = new System.Drawing.Point(269, 157);
            this.won.Name = "won";
            this.won.Size = new System.Drawing.Size(21, 17);
            this.won.TabIndex = 35;
            this.won.Text = "원";
            // 
            // Purchase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 242);
            this.Controls.Add(this.won);
            this.Controls.Add(this.CancleBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.priceLabel);
            this.Controls.Add(this.OkBtn);
            this.Controls.Add(this.txtAllprice);
            this.Controls.Add(this.PurchaseBtn);
            this.Controls.Add(this.Pnum);
            this.Controls.Add(this.WelcomeUser);
            this.Name = "Purchase";
            this.Text = "Purchase";
            this.Load += new System.EventHandler(this.Purchase_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeUser;
        private System.Windows.Forms.Button PurchaseBtn;
        private System.Windows.Forms.TextBox Pnum;
        private System.Windows.Forms.Button OkBtn;
        private System.Windows.Forms.TextBox txtAllprice;
        private System.Windows.Forms.Label priceLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CancleBtn;
        private System.Windows.Forms.Label won;
    }
}