﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sellbuy_Winform
{
    public class Seller
    {
        public string Id { get; set; }
        public string Password { get; set; }
        public int Money { get; set; }
        public int ProductNum { get; set; }
        public int ProductPrice { get; set; }

        public Seller(string Id,string Password,int Money,int ProductNum,int ProductPrice)
        {
            this.Id = Id;
            this.Password = Password;
            this.Money = Money;
            this.ProductNum = ProductNum;
            this.ProductPrice = ProductPrice;
        }
    }
}
