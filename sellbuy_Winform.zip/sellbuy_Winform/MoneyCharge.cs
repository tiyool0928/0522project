﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class MoneyCharge : Form
    {
        Buyer buyer;
        public MoneyCharge(Buyer buyer)
        {
            InitializeComponent();
            this.buyer = buyer;
        }

        private void OkBtn_Click(object sender, EventArgs e)
        {
            buyer.Money += int.Parse(txtMoney.Text);
            MessageBox.Show("금액이 충전되었습니다. 감사합니다");
            Close();
            new BuyerMenu(buyer).ShowDialog();
        }

        private void CancleBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
