﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sellbuy_Winform
{
    public class ProgramManager
    {
        public static List<Seller> sellers = new List<Seller>();
        public static List<Buyer> buyers = new List<Buyer>();

        public static int SellerRegister(string id,string passwd,int Pnum, int Pprice)
        {
            foreach (Seller seller in sellers)
            {
                if (seller.Id == id)
                {
                    return 1;
                }
            }
            sellers.Add(new Seller(id, passwd,Pnum,Pprice));
            return 0;
        }

        public static int BuyerRegister(string id, string passwd)
        {
            foreach (Buyer buyer in buyers)
            {
                if(buyer.Id == id)
                {
                    return 1;
                }
            }
            buyers.Add(new Buyer(id, passwd));
            return 0;
        }

        public static Seller SellerLogin(string id,string passwd)
        {
            foreach (Seller seller in sellers)
            {
                if(seller.Id == id && seller.Password == passwd)
                {
                    return seller;
                }
                else if(seller.Id == id)
                {
                    return null;
                }
            }
            return null;
        }

        public static Buyer BuyerLogin(string id, string passwd)
        {
            foreach (Buyer buyer in buyers)
            {
                if (buyer.Id == id && buyer.Password == passwd)
                {
                    return buyer;
                }
                else if (buyer.Id == id)
                {
                    return null;
                }
            }
            return null;
        }
    }

}
