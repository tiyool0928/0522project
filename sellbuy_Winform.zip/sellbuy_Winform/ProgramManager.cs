﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sellbuy_Winform
{
    public class ProgramManager
    {
        public static List<Seller> sellers = new List<Seller>();
        public static List<Buyer> buyers = new List<Buyer>();
    }
}
