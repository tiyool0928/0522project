﻿namespace sellbuy_Winform
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.loginBtn = new System.Windows.Forms.Button();
            this.txtPasswd = new System.Windows.Forms.TextBox();
            this.txtId = new System.Windows.Forms.TextBox();
            this.buyerBtn = new System.Windows.Forms.RadioButton();
            this.sellerBtn = new System.Windows.Forms.RadioButton();
            this.backBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("바탕", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(361, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 24);
            this.label3.TabIndex = 13;
            this.label3.Text = "로그인";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(255, 194);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 12);
            this.label1.TabIndex = 14;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(235, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "Password";
            // 
            // loginBtn
            // 
            this.loginBtn.Location = new System.Drawing.Point(509, 184);
            this.loginBtn.Name = "loginBtn";
            this.loginBtn.Size = new System.Drawing.Size(124, 32);
            this.loginBtn.TabIndex = 18;
            this.loginBtn.Text = "로그인";
            this.loginBtn.UseVisualStyleBackColor = true;
            this.loginBtn.Click += new System.EventHandler(this.loginBtn_Click);
            // 
            // txtPasswd
            // 
            this.txtPasswd.Location = new System.Drawing.Point(303, 235);
            this.txtPasswd.Name = "txtPasswd";
            this.txtPasswd.Size = new System.Drawing.Size(180, 21);
            this.txtPasswd.TabIndex = 17;
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(303, 191);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(180, 21);
            this.txtId.TabIndex = 16;
            // 
            // buyerBtn
            // 
            this.buyerBtn.AutoSize = true;
            this.buyerBtn.Location = new System.Drawing.Point(412, 159);
            this.buyerBtn.Name = "buyerBtn";
            this.buyerBtn.Size = new System.Drawing.Size(59, 16);
            this.buyerBtn.TabIndex = 20;
            this.buyerBtn.TabStop = true;
            this.buyerBtn.Text = "구매자";
            this.buyerBtn.UseVisualStyleBackColor = true;
            // 
            // sellerBtn
            // 
            this.sellerBtn.AutoSize = true;
            this.sellerBtn.Location = new System.Drawing.Point(314, 159);
            this.sellerBtn.Name = "sellerBtn";
            this.sellerBtn.Size = new System.Drawing.Size(59, 16);
            this.sellerBtn.TabIndex = 19;
            this.sellerBtn.TabStop = true;
            this.sellerBtn.Text = "판매자";
            this.sellerBtn.UseVisualStyleBackColor = true;
            // 
            // backBtn
            // 
            this.backBtn.Location = new System.Drawing.Point(509, 228);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(124, 32);
            this.backBtn.TabIndex = 21;
            this.backBtn.Text = "뒤로";
            this.backBtn.UseVisualStyleBackColor = true;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.buyerBtn);
            this.Controls.Add(this.sellerBtn);
            this.Controls.Add(this.loginBtn);
            this.Controls.Add(this.txtPasswd);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Name = "Login";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button loginBtn;
        private System.Windows.Forms.TextBox txtPasswd;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.RadioButton buyerBtn;
        private System.Windows.Forms.RadioButton sellerBtn;
        private System.Windows.Forms.Button backBtn;
    }
}