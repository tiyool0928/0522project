﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
            sellerInforOff();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(sellerBtn.Checked)
            {

            }
            else if(buyerBtn.Checked)
            {

            }
        }

        private void sellerBtn_CheckedChanged(object sender, EventArgs e)
        {
            sellerInforOn();
        }

        private void buyerBtn_CheckedChanged(object sender, EventArgs e)
        {
            sellerInforOff();
        }

        void sellerInforOn()
        {
            labelPnum.Visible = true;
            labelPprice.Visible = true;
            txtPnum.Visible = true;
            txtPprice.Visible = true;
        }
        void sellerInforOff()
        {
            labelPnum.Visible = false;
            labelPprice.Visible = false;
            txtPnum.Visible = false;
            txtPprice.Visible = false;
        }

       
    }
}
