﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
            sellerInforOff();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(sellerBtn.Checked)
            {
                int result1 = ProgramManager.SellerRegister(txtId.Text, txtPasswd.Text, int.Parse(txtPnum.Text), int.Parse(txtPprice.Text));
                if(result1 == 1)
                {
                    MessageBox.Show("아이디가 중복됩니다. 다시 시도해주세요");
                }
                else
                {
                    MessageBox.Show("회원가입이 완료되었습니다.");
                    this.Close();
                }
            }
            else if(buyerBtn.Checked)
            {
               int result2 = ProgramManager.BuyerRegister(txtId.Text, txtPasswd.Text);
                if (result2 == 1)
                {
                    MessageBox.Show("아이디가 중복됩니다. 다시 시도해주세요");
                }
                else
                {
                    MessageBox.Show("회원가입이 완료되었습니다.");
                    this.Close();
                }
            }
        }

        private void sellerBtn_CheckedChanged(object sender, EventArgs e)
        {
            sellerInforOn();
        }

        private void buyerBtn_CheckedChanged(object sender, EventArgs e)
        {
            sellerInforOff();
        }

        void sellerInforOn()
        {
            labelPnum.Visible = true;
            labelPprice.Visible = true;
            txtPnum.Visible = true;
            txtPprice.Visible = true;
        }
        void sellerInforOff()
        {
            labelPnum.Visible = false;
            labelPprice.Visible = false;
            txtPnum.Visible = false;
            txtPprice.Visible = false;
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }

        private void CancleBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
