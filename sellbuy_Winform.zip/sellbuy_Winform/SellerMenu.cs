﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class SellerMenu : Form
    {
        public Seller seller;
        public SellerMenu(Seller seller)
        {
            InitializeComponent();
            WelcomeUser.Text = string.Format("환영합니다 {0}님",seller.Id);
            VisableOff();
            this.seller = seller;
        }

        private void SellerMenu_Load(object sender, EventArgs e)
        {

        }

        private void WelcomeUser_Click(object sender, EventArgs e)
        {

        }

        private void PnumBtn_Click(object sender, EventArgs e)
        {
            txtPnum.Text = (Convert.ToString(seller.ProductNum));
            txtPnum.Visible = true;
            PnumCharge.Visible = true;
        }

        private void PpriceBtn_Click(object sender, EventArgs e)
        {
            txtPprice.Text = (Convert.ToString(seller.ProductPrice));
            txtPprice.Visible = true;
            PpriceCharge.Visible = true;
        }

        private void MoneyBtn_Click(object sender, EventArgs e)
        {
            txtMoney.Text = (Convert.ToString(seller.Money));
            txtMoney.Visible = true;
            MoneySettle.Visible = true;
        }

        private void PnumCharge_Click(object sender, EventArgs e)
        {
            new PnumCharge(seller).ShowDialog();
            VisableOff();
        }

        private void PpriceCharge_Click(object sender, EventArgs e)
        {
            new PpriceCharge(seller).ShowDialog();
            VisableOff();
        }

        private void MoneySettle_Click(object sender, EventArgs e)
        {
            seller.Money = 0;
            MessageBox.Show("매출이 모두 정산되었습니다. 감사합니다");
            VisableOff();
        }

        public void VisableOff()
        {
            txtPnum.Visible = false;
            txtPprice.Visible = false;
            txtMoney.Visible = false;
            PnumCharge.Visible = false;
            PpriceCharge.Visible = false;
            MoneySettle.Visible = false;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
