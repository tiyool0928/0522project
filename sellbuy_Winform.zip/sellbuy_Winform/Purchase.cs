﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class Purchase : Form
    {
        Seller seller;
        Buyer buyer;
        public Purchase(Seller seller,Buyer buyer)
        {
            InitializeComponent();
            this.seller = seller;
            this.buyer = buyer;
        }

        private void Purchase_Load(object sender, EventArgs e)
        {
            priceLabel.Visible = false;
            txtAllprice.Visible = false;
            OkBtn.Visible = false;
            won.Visible = false;
        }

        private void PurchaseBtn_Click(object sender, EventArgs e)
        {
            int Allprice = seller.ProductPrice * int.Parse(Pnum.Text);
            txtAllprice.Text = string.Format("{0}", Allprice);
            priceLabel.Visible = true;
            txtAllprice.Visible = true;
            OkBtn.Visible = true;
            won.Visible = true;
        }

        private void OkBtn_Click(object sender, EventArgs e)
        {
            buyer.Money -= int.Parse(txtAllprice.Text);
            seller.Money += int.Parse(txtAllprice.Text);
            seller.ProductNum -= int.Parse(Pnum.Text);
            MessageBox.Show("구입이 완료되었습니다.");
            Close();
            new BuyerMenu(buyer).ShowDialog();
        }

        private void CancleBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
