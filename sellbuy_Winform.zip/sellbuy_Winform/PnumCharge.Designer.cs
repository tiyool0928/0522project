﻿namespace sellbuy_Winform
{
    partial class PnumCharge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeUser = new System.Windows.Forms.Label();
            this.txtPnum = new System.Windows.Forms.TextBox();
            this.ChargeBtn = new System.Windows.Forms.Button();
            this.CancleBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WelcomeUser
            // 
            this.WelcomeUser.AutoSize = true;
            this.WelcomeUser.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.WelcomeUser.Location = new System.Drawing.Point(76, 27);
            this.WelcomeUser.Name = "WelcomeUser";
            this.WelcomeUser.Size = new System.Drawing.Size(218, 17);
            this.WelcomeUser.TabIndex = 1;
            this.WelcomeUser.Text = "충전할 상품의 갯수를 입력해주세요";
            // 
            // txtPnum
            // 
            this.txtPnum.Location = new System.Drawing.Point(93, 64);
            this.txtPnum.Name = "txtPnum";
            this.txtPnum.Size = new System.Drawing.Size(180, 21);
            this.txtPnum.TabIndex = 19;
            // 
            // ChargeBtn
            // 
            this.ChargeBtn.Location = new System.Drawing.Point(279, 47);
            this.ChargeBtn.Name = "ChargeBtn";
            this.ChargeBtn.Size = new System.Drawing.Size(49, 25);
            this.ChargeBtn.TabIndex = 23;
            this.ChargeBtn.Text = "충전";
            this.ChargeBtn.UseVisualStyleBackColor = true;
            this.ChargeBtn.Click += new System.EventHandler(this.ChargeBtn_Click);
            // 
            // CancleBtn
            // 
            this.CancleBtn.Location = new System.Drawing.Point(279, 78);
            this.CancleBtn.Name = "CancleBtn";
            this.CancleBtn.Size = new System.Drawing.Size(49, 25);
            this.CancleBtn.TabIndex = 24;
            this.CancleBtn.Text = "취소";
            this.CancleBtn.UseVisualStyleBackColor = true;
            this.CancleBtn.Click += new System.EventHandler(this.CancleBtn_Click);
            // 
            // PnumCharge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 136);
            this.Controls.Add(this.CancleBtn);
            this.Controls.Add(this.ChargeBtn);
            this.Controls.Add(this.txtPnum);
            this.Controls.Add(this.WelcomeUser);
            this.Name = "PnumCharge";
            this.Text = "PnumCharge";
            this.Load += new System.EventHandler(this.PnumCharge_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeUser;
        private System.Windows.Forms.TextBox txtPnum;
        private System.Windows.Forms.Button ChargeBtn;
        private System.Windows.Forms.Button CancleBtn;
    }
}