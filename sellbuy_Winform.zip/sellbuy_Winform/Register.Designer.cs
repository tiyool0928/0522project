﻿namespace sellbuy_Winform
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.RegisterBtn = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sellerBtn = new System.Windows.Forms.RadioButton();
            this.buyerBtn = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPnum = new System.Windows.Forms.TextBox();
            this.txtPprice = new System.Windows.Forms.TextBox();
            this.labelPnum = new System.Windows.Forms.Label();
            this.labelPprice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(216, 117);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(180, 21);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(216, 161);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(180, 21);
            this.textBox2.TabIndex = 1;
            // 
            // RegisterBtn
            // 
            this.RegisterBtn.Location = new System.Drawing.Point(422, 117);
            this.RegisterBtn.Name = "RegisterBtn";
            this.RegisterBtn.Size = new System.Drawing.Size(124, 36);
            this.RegisterBtn.TabIndex = 2;
            this.RegisterBtn.Text = "회원가입";
            this.RegisterBtn.UseVisualStyleBackColor = true;
            this.RegisterBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sellerBtn
            // 
            this.sellerBtn.AutoSize = true;
            this.sellerBtn.Location = new System.Drawing.Point(216, 95);
            this.sellerBtn.Name = "sellerBtn";
            this.sellerBtn.Size = new System.Drawing.Size(59, 16);
            this.sellerBtn.TabIndex = 4;
            this.sellerBtn.TabStop = true;
            this.sellerBtn.Text = "판매자";
            this.sellerBtn.UseVisualStyleBackColor = true;
            this.sellerBtn.CheckedChanged += new System.EventHandler(this.sellerBtn_CheckedChanged);
            // 
            // buyerBtn
            // 
            this.buyerBtn.AutoSize = true;
            this.buyerBtn.Location = new System.Drawing.Point(314, 95);
            this.buyerBtn.Name = "buyerBtn";
            this.buyerBtn.Size = new System.Drawing.Size(59, 16);
            this.buyerBtn.TabIndex = 5;
            this.buyerBtn.TabStop = true;
            this.buyerBtn.Text = "구매자";
            this.buyerBtn.UseVisualStyleBackColor = true;
            this.buyerBtn.CheckedChanged += new System.EventHandler(this.buyerBtn_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(171, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(148, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 12);
            this.label2.TabIndex = 7;
            this.label2.Text = "Password";
            // 
            // txtPnum
            // 
            this.txtPnum.Location = new System.Drawing.Point(216, 210);
            this.txtPnum.Name = "txtPnum";
            this.txtPnum.Size = new System.Drawing.Size(180, 21);
            this.txtPnum.TabIndex = 8;
            // 
            // txtPprice
            // 
            this.txtPprice.Location = new System.Drawing.Point(216, 260);
            this.txtPprice.Name = "txtPprice";
            this.txtPprice.Size = new System.Drawing.Size(180, 21);
            this.txtPprice.TabIndex = 9;
            // 
            // labelPnum
            // 
            this.labelPnum.AutoSize = true;
            this.labelPnum.Location = new System.Drawing.Point(148, 213);
            this.labelPnum.Name = "labelPnum";
            this.labelPnum.Size = new System.Drawing.Size(53, 12);
            this.labelPnum.TabIndex = 10;
            this.labelPnum.Text = "물품개수";
            // 
            // labelPprice
            // 
            this.labelPprice.AutoSize = true;
            this.labelPprice.Location = new System.Drawing.Point(148, 263);
            this.labelPprice.Name = "labelPprice";
            this.labelPprice.Size = new System.Drawing.Size(53, 12);
            this.labelPprice.TabIndex = 11;
            this.labelPprice.Text = "물품가격";
            // 
            // Register
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.labelPprice);
            this.Controls.Add(this.labelPnum);
            this.Controls.Add(this.txtPprice);
            this.Controls.Add(this.txtPnum);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buyerBtn);
            this.Controls.Add(this.sellerBtn);
            this.Controls.Add(this.RegisterBtn);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Register";
            this.Text = "Register";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button RegisterBtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.RadioButton sellerBtn;
        private System.Windows.Forms.RadioButton buyerBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPnum;
        private System.Windows.Forms.TextBox txtPprice;
        private System.Windows.Forms.Label labelPnum;
        private System.Windows.Forms.Label labelPprice;
    }
}