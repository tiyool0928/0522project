﻿namespace sellbuy_Winform
{
    partial class BuyerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeUser = new System.Windows.Forms.Label();
            this.MoneyCharge = new System.Windows.Forms.Button();
            this.txtMoney = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // WelcomeUser
            // 
            this.WelcomeUser.AutoSize = true;
            this.WelcomeUser.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.WelcomeUser.Location = new System.Drawing.Point(420, 33);
            this.WelcomeUser.Name = "WelcomeUser";
            this.WelcomeUser.Size = new System.Drawing.Size(83, 17);
            this.WelcomeUser.TabIndex = 1;
            this.WelcomeUser.Text = "~~님의 잔액";
            this.WelcomeUser.Click += new System.EventHandler(this.WelcomeUser_Click);
            // 
            // MoneyCharge
            // 
            this.MoneyCharge.Location = new System.Drawing.Point(708, 26);
            this.MoneyCharge.Name = "MoneyCharge";
            this.MoneyCharge.Size = new System.Drawing.Size(53, 32);
            this.MoneyCharge.TabIndex = 24;
            this.MoneyCharge.Text = "충전";
            this.MoneyCharge.UseVisualStyleBackColor = true;
            // 
            // txtMoney
            // 
            this.txtMoney.Location = new System.Drawing.Point(509, 33);
            this.txtMoney.Name = "txtMoney";
            this.txtMoney.Size = new System.Drawing.Size(180, 21);
            this.txtMoney.TabIndex = 23;
            // 
            // BuyerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.MoneyCharge);
            this.Controls.Add(this.txtMoney);
            this.Controls.Add(this.WelcomeUser);
            this.Name = "BuyerMenu";
            this.Text = "BuyerMenu";
            this.Load += new System.EventHandler(this.BuyerMenu_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeUser;
        private System.Windows.Forms.Button MoneyCharge;
        private System.Windows.Forms.TextBox txtMoney;
    }
}