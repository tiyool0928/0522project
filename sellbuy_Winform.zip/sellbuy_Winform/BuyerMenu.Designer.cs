﻿using System;

namespace sellbuy_Winform
{
    partial class BuyerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.WelcomeUser = new System.Windows.Forms.Label();
            this.MoneyCharge = new System.Windows.Forms.Button();
            this.txtMoney = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtSellerInfor = new System.Windows.Forms.TextBox();
            this.PurchaseBtn = new System.Windows.Forms.Button();
            this.programManagerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.exitBtn = new System.Windows.Forms.Button();
            this.Tostart = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.programManagerBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // WelcomeUser
            // 
            this.WelcomeUser.AutoSize = true;
            this.WelcomeUser.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.WelcomeUser.Location = new System.Drawing.Point(420, 33);
            this.WelcomeUser.Name = "WelcomeUser";
            this.WelcomeUser.Size = new System.Drawing.Size(83, 17);
            this.WelcomeUser.TabIndex = 1;
            this.WelcomeUser.Text = "~~님의 잔액";
            this.WelcomeUser.Click += new System.EventHandler(this.WelcomeUser_Click);
            // 
            // MoneyCharge
            // 
            this.MoneyCharge.Location = new System.Drawing.Point(708, 26);
            this.MoneyCharge.Name = "MoneyCharge";
            this.MoneyCharge.Size = new System.Drawing.Size(53, 32);
            this.MoneyCharge.TabIndex = 24;
            this.MoneyCharge.Text = "충전";
            this.MoneyCharge.UseVisualStyleBackColor = true;
            this.MoneyCharge.Click += new System.EventHandler(this.MoneyCharge_Click);
            // 
            // txtMoney
            // 
            this.txtMoney.Location = new System.Drawing.Point(509, 33);
            this.txtMoney.Name = "txtMoney";
            this.txtMoney.Size = new System.Drawing.Size(180, 21);
            this.txtMoney.TabIndex = 23;
            this.txtMoney.TextChanged += new System.EventHandler(this.txtMoney_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.productNumDataGridViewTextBoxColumn,
            this.productPriceDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.sellerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(32, 33);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(343, 405);
            this.dataGridView1.TabIndex = 25;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // productNumDataGridViewTextBoxColumn
            // 
            this.productNumDataGridViewTextBoxColumn.DataPropertyName = "ProductNum";
            this.productNumDataGridViewTextBoxColumn.HeaderText = "ProductNum";
            this.productNumDataGridViewTextBoxColumn.Name = "productNumDataGridViewTextBoxColumn";
            this.productNumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // productPriceDataGridViewTextBoxColumn
            // 
            this.productPriceDataGridViewTextBoxColumn.DataPropertyName = "ProductPrice";
            this.productPriceDataGridViewTextBoxColumn.HeaderText = "ProductPrice";
            this.productPriceDataGridViewTextBoxColumn.Name = "productPriceDataGridViewTextBoxColumn";
            this.productPriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sellerBindingSource
            // 
            this.sellerBindingSource.DataSource = typeof(sellbuy_Winform.Seller);
            // 
            // txtSellerInfor
            // 
            this.txtSellerInfor.Location = new System.Drawing.Point(423, 219);
            this.txtSellerInfor.Name = "txtSellerInfor";
            this.txtSellerInfor.Size = new System.Drawing.Size(266, 21);
            this.txtSellerInfor.TabIndex = 26;
            // 
            // PurchaseBtn
            // 
            this.PurchaseBtn.Location = new System.Drawing.Point(708, 212);
            this.PurchaseBtn.Name = "PurchaseBtn";
            this.PurchaseBtn.Size = new System.Drawing.Size(53, 32);
            this.PurchaseBtn.TabIndex = 27;
            this.PurchaseBtn.Text = "구매";
            this.PurchaseBtn.UseVisualStyleBackColor = true;
            this.PurchaseBtn.Click += new System.EventHandler(this.PurchaseBtn_Click);
            // 
            // programManagerBindingSource
            // 
            this.programManagerBindingSource.DataSource = typeof(sellbuy_Winform.ProgramManager);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(460, 365);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(239, 32);
            this.exitBtn.TabIndex = 28;
            this.exitBtn.Text = "프로그램 종료";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // Tostart
            // 
            this.Tostart.Location = new System.Drawing.Point(460, 327);
            this.Tostart.Name = "Tostart";
            this.Tostart.Size = new System.Drawing.Size(239, 32);
            this.Tostart.TabIndex = 29;
            this.Tostart.Text = "시작 화면으로";
            this.Tostart.UseVisualStyleBackColor = true;
            this.Tostart.Click += new System.EventHandler(this.Tostart_Click);
            // 
            // BuyerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Tostart);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.PurchaseBtn);
            this.Controls.Add(this.txtSellerInfor);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.MoneyCharge);
            this.Controls.Add(this.txtMoney);
            this.Controls.Add(this.WelcomeUser);
            this.Name = "BuyerMenu";
            this.Text = "BuyerMenu";
            this.Load += new System.EventHandler(this.BuyerMenu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sellerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.programManagerBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void txtMoney_TextChanged(object sender, EventArgs e)
        {

        }

        #endregion

        private System.Windows.Forms.Label WelcomeUser;
        private System.Windows.Forms.Button MoneyCharge;
        private System.Windows.Forms.TextBox txtMoney;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sellerBindingSource;
        private System.Windows.Forms.BindingSource programManagerBindingSource;
        private System.Windows.Forms.TextBox txtSellerInfor;
        private System.Windows.Forms.Button PurchaseBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button Tostart;
    }
}