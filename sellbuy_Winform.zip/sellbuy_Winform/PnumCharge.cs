﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class PnumCharge : Form
    {
        Seller seller;
        public PnumCharge(Seller seller)
        {
            InitializeComponent();
            this.seller = seller;
        }

        private void ChargeBtn_Click(object sender, EventArgs e)
        {
            seller.ProductNum += int.Parse(txtPnum.Text);
            MessageBox.Show("물품이 충전되었습니다.");
            this.Close();
        }

        private void CancleBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PnumCharge_Load(object sender, EventArgs e)
        {

        }
    }
}
