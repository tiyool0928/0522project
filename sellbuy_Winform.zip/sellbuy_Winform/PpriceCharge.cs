﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sellbuy_Winform
{
    public partial class PpriceCharge : Form
    {
        Seller seller;
        public PpriceCharge(Seller seller)
        {
            InitializeComponent();
            this.seller = seller;
        }

        private void PpriceCharge_Load(object sender, EventArgs e)
        {

        }

        private void OkBtn_Click(object sender, EventArgs e)
        {
            seller.ProductPrice = 0;
            seller.ProductPrice += int.Parse(txtPprice.Text);
            MessageBox.Show("가격이 변경되었습니다.");
            this.Close();
        }

        private void CancleBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
