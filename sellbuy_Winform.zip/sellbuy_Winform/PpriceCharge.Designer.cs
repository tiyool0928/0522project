﻿namespace sellbuy_Winform
{
    partial class PpriceCharge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CancleBtn = new System.Windows.Forms.Button();
            this.OkBtn = new System.Windows.Forms.Button();
            this.txtPprice = new System.Windows.Forms.TextBox();
            this.WelcomeUser = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // CancleBtn
            // 
            this.CancleBtn.Location = new System.Drawing.Point(264, 80);
            this.CancleBtn.Name = "CancleBtn";
            this.CancleBtn.Size = new System.Drawing.Size(49, 25);
            this.CancleBtn.TabIndex = 28;
            this.CancleBtn.Text = "취소";
            this.CancleBtn.UseVisualStyleBackColor = true;
            this.CancleBtn.Click += new System.EventHandler(this.CancleBtn_Click);
            // 
            // OkBtn
            // 
            this.OkBtn.Location = new System.Drawing.Point(264, 49);
            this.OkBtn.Name = "OkBtn";
            this.OkBtn.Size = new System.Drawing.Size(49, 25);
            this.OkBtn.TabIndex = 27;
            this.OkBtn.Text = "확인";
            this.OkBtn.UseVisualStyleBackColor = true;
            this.OkBtn.Click += new System.EventHandler(this.OkBtn_Click);
            // 
            // txtPprice
            // 
            this.txtPprice.Location = new System.Drawing.Point(78, 66);
            this.txtPprice.Name = "txtPprice";
            this.txtPprice.Size = new System.Drawing.Size(180, 21);
            this.txtPprice.TabIndex = 26;
            // 
            // WelcomeUser
            // 
            this.WelcomeUser.AutoSize = true;
            this.WelcomeUser.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.WelcomeUser.Location = new System.Drawing.Point(87, 31);
            this.WelcomeUser.Name = "WelcomeUser";
            this.WelcomeUser.Size = new System.Drawing.Size(161, 17);
            this.WelcomeUser.TabIndex = 25;
            this.WelcomeUser.Text = "가격을 다시 책정하십시오";
            // 
            // PpriceCharge
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 134);
            this.Controls.Add(this.CancleBtn);
            this.Controls.Add(this.OkBtn);
            this.Controls.Add(this.txtPprice);
            this.Controls.Add(this.WelcomeUser);
            this.Name = "PpriceCharge";
            this.Text = "PpriceCharge";
            this.Load += new System.EventHandler(this.PpriceCharge_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button CancleBtn;
        private System.Windows.Forms.Button OkBtn;
        private System.Windows.Forms.TextBox txtPprice;
        private System.Windows.Forms.Label WelcomeUser;
    }
}