﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label5.Text = DataManager.books.Count.ToString();
            label6.Text = DataManager.users.Count.ToString();
            label7.Text = DataManager.books.Where(x => x.IsBorrowed).Count().ToString();
            label8.Text = DataManager.books.Where(x =>
            {return x.IsBorrowed && x.BorrowedAt.AddDays(7) < DateTime.Now;}).Count().ToString();

            dataGridView1.DataSource = DataManager.books;
            dataGridView2.DataSource = DataManager.users;

            dataGridView1.CurrentCellChanged += DataGridView1_CurrentCellChanged;
            dataGridView2.CurrentCellChanged += DataGridView2_CurrentCellChanged;
        }

        private void DataGridView2_CurrentCellChanged(object sender, EventArgs e)
        {
            textBox3.Text = (dataGridView1.CurrentRow.DataBoundItem as User).Id.ToString();
        }

        private void DataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {
            textBox1.Text = (dataGridView1.CurrentRow.DataBoundItem as Book).isbn;
            textBox2.Text = (dataGridView1.CurrentRow.DataBoundItem as Book).Name;
        }

        private void 도서관리ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form2().ShowDialog();
        }

        private void 사용자관리ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Form3().ShowDialog();
        }
    }
}
