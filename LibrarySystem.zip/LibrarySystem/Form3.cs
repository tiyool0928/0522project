﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            dataGridView1.CurrentCellChanged += DataGridView1_CurrentCellChanged;
        }

        private void DataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {
            textBox1.Text = (dataGridView1.CurrentRow.DataBoundItem as User).Id.ToString();
            textBox2.Text = (dataGridView1.CurrentRow.DataBoundItem as User).Name;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (DataManager.users.Exists(x => x.Id == int.Parse(textBox1.Text)))
                {
                    MessageBox.Show("이미 존재하는 아이디입니다.");
                }
                else
                {
                    User user = new User()
                    {
                        Id = int.Parse(textBox1.Text),
                        Name = textBox2.Text
                    };
                    DataManager.users.Add(user);

                    dataGridView1.DataSource = null;
                    dataGridView1.DataSource = DataManager.users;
                    DataManager.Save();
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                User user = DataManager.users.Single(x => x.Id == int.Parse(textBox1.Text));
                user.Name = textBox2.Text;

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = DataManager.users;
                DataManager.Save();
            }
            catch (Exception)
            {
                MessageBox.Show("존재하지 않는 사용자입니다.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                User user = DataManager.users.Single(x => x.Name == textBox1.Text);
                DataManager.users.Remove(user);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = DataManager.users;
                DataManager.Save();
            }
            catch (Exception)
            {
                MessageBox.Show("존재하지 않는 사용자입니다.");
            }
        }
    }
}
