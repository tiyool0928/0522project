﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            dataGridView1.DataSource = DataManager.books;

            button1.Click += (sender, e) =>
            {
                try
                {
                    if (DataManager.books.Exists(x => x.isbn == textBox1.Text))
                    {
                        MessageBox.Show("이미 존재하는 도서입니다.");
                    }
                    else
                    {
                        Book book = new Book()
                        {
                            isbn = textBox1.Text,
                            Name = textBox2.Text,
                            Publisher = textBox3.Text,
                            Page = int.Parse(textBox4.Text)
                        };
                        DataManager.books.Add(book);

                        dataGridView1.DataSource = null;
                        dataGridView1.DataSource = DataManager.books;
                        DataManager.Save();
                    }
                }
                catch (Exception)
                {

                    throw;
                }
                
            };
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.CurrentCellChanged += DataGridView1_CurrentCellChanged;
        }

        private void DataGridView1_CurrentCellChanged(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = (dataGridView1.CurrentRow.DataBoundItem as Book).isbn;
                textBox2.Text = (dataGridView1.CurrentRow.DataBoundItem as Book).Name;
                textBox3.Text = (dataGridView1.CurrentRow.DataBoundItem as Book).Publisher;
                textBox4.Text = (dataGridView1.CurrentRow.DataBoundItem as Book).Page.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Book book = DataManager.books.Single(x => x.isbn == textBox1.Text);
                book.Name = textBox2.Text;
                book.Publisher = textBox3.Text;
                book.Page = int.Parse(textBox4.Text);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = DataManager.books;
                DataManager.Save();
            }
            catch (Exception)
            {

                MessageBox.Show("존재하지 않는 도서입니다.");
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Book book = DataManager.books.Single(x => x.isbn == textBox1.Text);
                DataManager.books.Remove(book);

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = DataManager.books;
                DataManager.Save();
            }
            catch (Exception)
            {
                MessageBox.Show("존재하지 않는 도서입니다.");

            }
           
        }

        
    }
}
