﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LibrarySystem
{
    public class DataManager
    {
        public static List<Book> books = new List<Book>();
        public static List<User> users = new List<User>();

        static DataManager()
        {
            Load();
        }

        private static void Load()
        {
            try
            {
               string booksOutput = File.ReadAllText($"./Books.xml");
                XElement bookXElement= XElement.Parse(booksOutput);
                books = (from item in bookXElement.Descendants("book")
                 select new Book
                 {
                     isbn = item.Element("Isbn").Value,
                     Name = item.Element("Name").Value,
                     Publisher = item.Element("Publisher").Value,
                     Page = int.Parse(item.Element("Page").Value),
                     UserId = int.Parse(item.Element("Name").Value),
                     UserName = item.Element("UserName").Value,
                     IsBorrowed = item.Element("IsBorrowed").Value != "0" ? true : false,
                     BorrowedAt = DateTime.Parse(item.Element("BorrowedAt").Value),
                 }).ToList<Book>();

                string usersOutput = File.ReadAllText($"Users.xml");
                XElement userXElement = XElement.Parse(usersOutput);
                users = (from item in userXElement.Descendants("user")
                         select new User
                         {
                             Id = int.Parse(item.Element("Id").Value),
                             Name = item.Element("Name").Value
                         }).ToList<User>();

            }
            catch(FileNotFoundException e)
            {
                Save();         //파일이 존재하지 않을 경우 처리
            }
        }
        public static void Save()
        {
            string bookOutput = "";
            bookOutput += "<books>\n";
            foreach (var item in books)
            {
                bookOutput += "<book>\n";
                bookOutput += "<Isbn>" + item.isbn + "</Isbn>\n";
                bookOutput += "<Name>" + item.Name + "</Name>\n";
                bookOutput += "<Publisher>" + item.Publisher + "</Publisher>\n";
                bookOutput += "<Page>" + item.Page + "</Page>\n";
                bookOutput += "<UserId>" + item.UserId + "</UserId>\n";
                bookOutput += "<UserName>" + item.UserName + "</UserName>\n";
                bookOutput += "<IsBorrowed>" + (item.IsBorrowed ? 1 : 0) + "</IsBorrowed>\n";
                bookOutput += "<BorrowedAt>" + item.BorrowedAt.ToLongDateString() + "</BorrowedAt>\n";
                bookOutput += "</book>";
            }
            bookOutput += "</books>";
            File.WriteAllText($"./Books.xml", bookOutput);

            string userOutput = "";
            userOutput += "<users>\n";
            foreach (var item in users)
            {
                userOutput += "<user>\n";
                userOutput += "<Id>" + item.Id + "</Id>\n";
                userOutput += "<Name>" + item.Name + "</Name>\n";
                userOutput += "</user>";
            }
            userOutput += "</users>";
            File.WriteAllText($"./users.xml", userOutput);
        }
    }
}
