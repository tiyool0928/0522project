#pragma once
#include <cstdio>

class Node
{
public:
	Node* link;
	int cols;
	int rows;

	Node(int r,int c) {
		rows = r;
		cols = c;
		link = NULL; 
	}
	~Node() {}
};
