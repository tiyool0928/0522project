package homework;

public class Member {
	private String id, passwd;
	static int count = 0;

	public Member(String tId, String tPwd) {
		id = tId;
		passwd = tPwd;
		count++;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String tId) {
		id = tId;
	}

	public String getPasswd() {
		return this.passwd;
	}

	public void setPasswd(String tPwd) {
		passwd = tPwd;
	}
}
