package homework;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet{
	Member[] members;
	String adminId, adminPwd;
	public void init(ServletConfig config) throws ServletException {
		members = new Member[10];
		adminId = config.getInitParameter("adminId");
		adminPwd = config.getInitParameter("adminPwd");
	}
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		
		String id = req.getParameter("id");
		String pwd = req.getParameter("passwd");
		
		Member newMember = new Member(id,pwd);
		members[Member.count-1] = newMember;
		
		PrintWriter out = resp.getWriter();
		out.print("<html><head></head>");
		out.print("<body>"+id+" "+pwd+"</body>");
		out.print("</html>");
		out.close();
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,IOException{
		
		String loginId = req.getParameter("id");
		String loginPwd = req.getParameter("passwd");
		int i;
		if(adminId.equals(loginId) && adminPwd.equals(loginPwd)) {
			//������ �α��� ����
			
		}else if(adminId.equals(loginId)){
			// ������ passwd�� Ʋ��	
			
		}
		for( i = 0; i<Member.count; i++) {
			if(members[i].getId().equals(loginId) && members[i].getPasswd().equals(loginPwd)) {
				//�α��� ����
				break;
				
			}else if(members[i].getId().equals(loginId)){
				// passwd�� Ʋ��
				break;
				
			}
		}
		if (i == Member.count) {
			//id ���� ����
		}
	}
}
