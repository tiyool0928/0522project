﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buyer_Seller
{
    public class Controller
    {
        public static int BuyerRegister(string id,string pw)
        {
            string connstr = "server=localhost;user = root;password = cs1234;database = sellbuy";
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string sql = "insert into buyer values('" + id + "','" + pw + "',0);";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                return 1;
            }
            catch (Exception)
            {
                return 2;
            }
            finally
            {
                conn.Close();
            }
        }

        public static int SellerRegister(string id, string pw,int pnum, int pprice)
        {
            string connstr = "server=localhost;user = root;password = cs1234;database = sellbuy";
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string sql = "insert into seller values('" + id + "','" + pw + "'," + pnum + "," + pprice + ",0);";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                return 1;
            }
            catch (Exception)
            {
                return 2;
            }
            finally
            {
                conn.Close();
            }
        }

        public static int BuyerLogin(string id, string pw)
        {
            string connstr = "server=localhost;user = root;password = cs1234;database = sellbuy";
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string sql = "select * from buyer where id = '" + id + "' && password = '" + pw + "';";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                return 1;
            }
            catch (Exception)
            {
                return 2;
            }
            finally
            {
                conn.Close();
            }
        }

        public static int SellerLogin(string id, string pw)
        {
            string connstr = "server=localhost;user = root;password = cs1234;database = sellbuy";
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string sql = "select * from seller where id = '" + id + "' && password = '" + pw + "';";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                return 1;
            }
            catch (Exception)
            {
                return 2;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
