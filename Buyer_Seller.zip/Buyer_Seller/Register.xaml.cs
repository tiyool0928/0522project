﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buyer_Seller
{
    /// <summary>
    /// Register.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Register : Page
    {
        public Register()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if(BuyerBtn.IsChecked == true)
            {
                int result = Controller.BuyerRegister(IDtxt.Text, PWtxt.Text);
                if(result == 1)
                {
                    NavigationService.Navigate(new Uri("/Main.xaml", UriKind.Relative));
                    MessageBox.Show("구매자로 회원가입이 되었습니다!");
                }
                else if(result == 2)
                {
                    MessageBox.Show("ID가 중복되거나 서버가 불안정합니다.");
                }
            }
            else if(SellerBtn.IsChecked == true)
            {
                int result = Controller.SellerRegister(IDtxt.Text, PWtxt.Text,int.Parse(Pnumtxt.Text),int.Parse(Ppricetxt.Text));
                if(result == 1)
                {
                    NavigationService.Navigate(new Uri("/Main.xaml", UriKind.Relative));
                    MessageBox.Show("판매자로 회원가입이 되었습니다!");
                }
                else if(result == 2)
                {
                    MessageBox.Show("ID가 중복되거나 서버가 불안정합니다.");
                }
            }
        }

        private void BuyerBtn_Checked(object sender, RoutedEventArgs e)
        {
            Pnumtxt.IsReadOnly = true;
            Ppricetxt.IsReadOnly = true;
        }

        private void SellerBtn_Checked(object sender, RoutedEventArgs e)
        {
            Pnumtxt.IsReadOnly = false;
            Ppricetxt.IsReadOnly = false;
        }
    }
}
