﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Buyer_Seller
{
    public static class LoginSession
    {
        public static string LoginID { get; set; } = "";
        public static string LoginPassword { get; set; } = "";
    }
}
