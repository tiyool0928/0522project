﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Buyer_Seller
{
    /// <summary>
    /// BuyerMenu.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class BuyerMenu : Page
    {
        public BuyerMenu()
        {
            InitializeComponent();
            GridFill();
        }

        void GridFill()
        {
            string connstr = "server=localhost;user = root;password = cs1234;database = sellbuy";
            MySqlConnection conn = new MySqlConnection(connstr);
            try
            {
                string sql = "select id,ProductNum,ProductPrice from seller;";
                MySqlCommand cmdSel = new MySqlCommand(sql, conn);
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(cmdSel);
                da.Fill(dt);
                dgvSeller.DataContext = dt;
            }
            catch (Exception)
            {
                MessageBox.Show("DB 연결에 실패하였습니다.");
            }
            finally
            {
                conn.Close();
            }
        }

        private void dgvSeller_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
