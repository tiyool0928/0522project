﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_Structure
{
    public partial class BST : Form
    {
        List<int> bst = new List<int>(10);

        public BST()
        {
            InitializeComponent();
            Circular();
        }

        void Circular()
        {
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, Root.Width, Root.Height);
            Root.Region = new Region(path);
            tree1.Region = new Region(path);
            tree2.Region = new Region(path);
            tree3.Region = new Region(path);
            tree4.Region = new Region(path);
            tree5.Region = new Region(path);
            tree6.Region = new Region(path);
            tree7.Region = new Region(path);
            tree8.Region = new Region(path);
            tree9.Region = new Region(path);
            tree10.Region = new Region(path);
            tree11.Region = new Region(path);
            tree12.Region = new Region(path);
            tree13.Region = new Region(path);
            tree14.Region = new Region(path);
        }

        private void PushBtn_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int data = random.Next(1, 99);
            BubbleSort(data);
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            Search(int.Parse(txtNum.Text));
        }

        private void NewBtn_Click(object sender, EventArgs e)
        {
            newTree(int.Parse(txtNum.Text));
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                DeleteNode(int.Parse(txtNum.Text));
            }
            catch(Exception)
            {
                MessageBox.Show("해당 데이터가 존재하지 않습니다.");
            }
            
        }

        void temp(Label a,Label b)
        {
            Label temp = new Label();
            temp.Location = a.Location;
            a.Location = b.Location;
            b.Location = temp.Location;
            temp.Visible = false;
        }

        void BubbleSort(int data)
        {
            if (Root.Text == "")
            {
                Root.Text = data.ToString();
                bst.Add(data);
            }
            else
            {
                if (int.Parse(Root.Text) >= data)
                {
                    if (tree1.Text == "")
                    {
                        tree1.Text = data.ToString();
                        bst.Add(data);
                    }
                    else
                    {
                        if(int.Parse(tree1.Text) >= data)
                        {
                            if (tree3.Text == "")
                            {
                                tree3.Text = data.ToString();
                                bst.Add(data);
                            }
                            else
                            {
                                MessageBox.Show("높이를 넘는 요소가 나왔습니다. 다시 시도해주세요.\n" +
                                    "랜덤으로 나온 숫자: "+data);
                            }
                        }
                        else
                        {
                            if(tree4.Text == "")
                            {
                                tree4.Text = data.ToString();
                                bst.Add(data);
                            }
                            else
                            {
                                MessageBox.Show("높이를 넘는 요소가 나왔습니다. 다시 시도해주세요.\n" +
                                    "랜덤으로 나온 숫자: " + data);
                            }
                        }
                    }
                }
                else
                {
                    if(tree2.Text == "")
                    {
                        tree2.Text = data.ToString();
                        bst.Add(data);
                    }
                    else
                    {
                        if(int.Parse(tree2.Text) >= data)
                        {
                            if(tree5.Text == "")
                            {
                                tree5.Text = data.ToString();
                            }
                            else
                            {
                                MessageBox.Show("높이를 넘는 요소가 나왔습니다. 다시 시도해주세요." +
                                    "랜덤으로 나온 숫자: " + data);
                            }
                        }
                        else
                        {
                            if(tree6.Text == "")
                            {
                                tree6.Text = data.ToString();
                            }
                            else
                            {
                                MessageBox.Show("높이를 넘는 요소가 나왔습니다. 다시 시도해주세요." +
                                    "랜덤으로 나온 숫자: " + data);
                            }
                        }
                    }
                }
            }
        }

        public void Search(int a)
        {
            White();

            if (int.Parse(Root.Text) == a)
            {
                Root.BackColor = Color.Tomato;
            }
            else
            {
                Root.BackColor = Color.Tomato;
                Delay(1000);
                if (int.Parse(Root.Text) > a)
                {
                    if(int.Parse(tree1.Text) == a)
                    {
                        White();
                        tree1.BackColor = Color.Tomato;
                    }
                    else
                    {
                        White();
                        tree1.BackColor = Color.Tomato;
                        Delay(1000);
                        if (int.Parse(tree1.Text) > a)
                        {
                            if (int.Parse(tree3.Text) == a)
                            {
                                White();
                                tree3.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree3.BackColor = Color.Tomato;
                                Delay(1000);
                                MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                            }
                        }
                        else
                        {
                            if(int.Parse(tree4.Text) == a)
                            {
                                White();
                                tree4.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree4.BackColor = Color.Tomato;
                                Delay(1000);
                                MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                            }
                        }
                    }
                }
                else
                {
                    if (int.Parse(tree2.Text) == a)
                    {
                        White();
                        tree2.BackColor = Color.Tomato;
                    }
                    else
                    {
                        White();
                        tree2.BackColor = Color.Tomato;
                        Delay(1000);
                        if (int.Parse(tree2.Text) > a)
                        {
                            if (int.Parse(tree5.Text) == a)
                            {
                                White();
                                tree5.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree5.BackColor = Color.Tomato;
                                Delay(1000);
                                MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                            }
                        }
                        else
                        {
                            if (int.Parse(tree6.Text) == a)
                            {
                                White();
                                tree6.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree6.BackColor = Color.Tomato;
                                Delay(1000);
                                MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                            }
                        }
                    }
                }
            }
        }

        public void newTree(int a)
        {
            White();
            if (Root.Text == "")
            {
                Root.Text = txtNum.Text;
            }
            else if (int.Parse(Root.Text) == a)
            {
                Root.BackColor = Color.Tomato;
            }
            else
            {
                Root.BackColor = Color.Tomato;
                Delay(1000);
                if (int.Parse(Root.Text) > a)
                {
                    if(tree1.Text == "")
                    {
                        White();
                        tree1.Text = txtNum.Text;
                    }
                    else if (int.Parse(tree1.Text) == a)
                    {
                        White();
                        tree1.BackColor = Color.Tomato;
                    }
                    else
                    {
                        White();
                        tree1.BackColor = Color.Tomato;
                        Delay(1000);
                        if (int.Parse(tree1.Text) > a)
                        {
                            if(tree3.Text == "")
                            {
                                White();
                                tree3.Text = txtNum.Text;
                            }
                            else if (int.Parse(tree3.Text) == a)
                            {
                                White();
                                tree3.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree3.BackColor = Color.Tomato;
                                Delay(1000);
                                if(int.Parse(tree3.Text) > a)
                                {
                                    White();
                                    tree7.Visible = true;
                                    tree7.Text = txtNum.Text;
                                }
                                else
                                {
                                    White();
                                    tree8.Visible = true;
                                    tree8.Text = txtNum.Text;
                                }
                            }
                        }
                        else
                        {
                            if(tree4.Text == "")
                            {
                                White();
                                tree4.Text = txtNum.Text;
                            }
                            else if (int.Parse(tree4.Text) == a)
                            {
                                White();
                                tree4.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree4.BackColor = Color.Tomato;
                                Delay(1000);
                                if (int.Parse(tree4.Text) > a)
                                {
                                    White();
                                    tree9.Visible = true;
                                    tree9.Text = txtNum.Text;
                                }
                                else
                                {
                                    White();
                                    tree10.Visible = true;
                                    tree10.Text = txtNum.Text;
                                }
                            }
                        }
                    }
                }
                else
                {
                    if(tree2.Text == "")
                    {
                        White();
                        tree2.Text = txtNum.Text;
                    }
                    else if (int.Parse(tree2.Text) == a)
                    {
                        White();
                        tree2.BackColor = Color.Tomato;
                    }
                    else
                    {
                        White();
                        tree2.BackColor = Color.Tomato;
                        Delay(1000);
                        if (int.Parse(tree2.Text) > a)
                        {
                            if(tree5.Text == "")
                            {
                                White();
                                tree5.Text = txtNum.Text;
                            }
                            else if (int.Parse(tree5.Text) == a)
                            {
                                White();
                                tree5.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree5.BackColor = Color.Tomato;
                                Delay(1000);
                                if (int.Parse(tree5.Text) > a)
                                {
                                    White();
                                    tree11.Visible = true;
                                    tree11.Text = txtNum.Text;
                                }
                                else
                                {
                                    White();
                                    tree12.Visible = true;
                                    tree12.Text = txtNum.Text;
                                }
                            }
                        }
                        else
                        {
                            if (tree6.Text == "")
                            {
                                White();
                                tree6.Text = txtNum.Text;
                            }
                            else if (int.Parse(tree6.Text) == a)
                            {
                                White();
                                tree6.BackColor = Color.Tomato;
                            }
                            else
                            {
                                White();
                                tree6.BackColor = Color.Tomato;
                                Delay(1000);
                                if (int.Parse(tree6.Text) > a)
                                {
                                    White();
                                    tree13.Visible = true;
                                    tree13.Text = txtNum.Text;
                                }
                                else
                                {
                                    White();
                                    tree14.Visible = true;
                                    tree14.Text = txtNum.Text;
                                }
                            }
                        }
                    }
                }
            }
            Heightview();
        }

        public void DeleteNode(int a)
        {
            White();

            if (int.Parse(Root.Text) == a)
            {
                White();
                Root.BackColor = Color.Tomato;
                Delay(1000);
                if (tree11.Text != "")
                {
                    Root.Text = tree11.Text;
                    tree11.Visible = false;
                }
                else
                {
                    Root.Text = tree2.Text;
                    if (tree12.Text != "")
                    {
                        tree2.Text = tree5.Text;
                        tree5.Text = tree12.Text;
                        tree12.Visible = false;
                    }
                    else
                    {
                        tree2.Text = tree6.Text;
                        tree6.Visible = false;
                    }
                }
            }
            else
            {
                Root.BackColor = Color.Tomato;
                Delay(1000);
                if (int.Parse(Root.Text) > a)
                {
                    if (int.Parse(tree1.Text) == a)
                    {
                        White();
                        tree1.BackColor = Color.Tomato;
                        Delay(1000);
                        if(tree9.Text != "")
                        {
                            tree1.Text = tree9.Text;
                            tree9.Visible = false;
                        }
                        else
                        {
                            tree1.Text = tree4.Text;
                            if(tree10.Text != "")
                            {
                                tree4.Text = tree10.Text;
                                tree10.Visible = false;
                            }
                            else
                            {
                                tree4.Visible = false;
                            }
                        }
                    }
                    else
                    {
                        White();
                        tree1.BackColor = Color.Tomato;
                        Delay(1000);
                        if (int.Parse(tree1.Text) > a)
                        {
                            if (int.Parse(tree3.Text) == a)
                            {
                                White();
                                tree3.BackColor = Color.Tomato;
                                Delay(1000);
                                if(tree7.Text != "")
                                {
                                    tree3.Text = tree7.Text;
                                    tree7.Visible = false;
                                }
                                else
                                {
                                    tree3.Text = tree8.Text;
                                    tree8.Visible = false;
                                }
                            }
                            else
                            {
                                White();
                                tree3.BackColor = Color.Tomato;
                                Delay(1000);
                                if (int.Parse(tree3.Text) > a)
                                {
                                    if(int.Parse(tree7.Text) == a)
                                    {
                                        tree7.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree7.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                                else
                                {
                                    if (int.Parse(tree8.Text) == a)
                                    {
                                        tree8.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree8.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (int.Parse(tree4.Text) == a)
                            {
                                White();
                                tree4.BackColor = Color.Tomato;
                                Delay(1000);
                                if (tree9.Text != "")
                                {
                                    tree4.Text = tree9.Text;
                                    tree9.Visible = false;
                                }
                                else
                                {
                                    tree4.Text = tree10.Text;
                                    tree10.Visible = false;
                                }
                            }
                            else
                            {
                                White();
                                tree4.BackColor = Color.Tomato;
                                Delay(1000);
                                if (int.Parse(tree4.Text) > a)
                                {
                                    if (int.Parse(tree9.Text) == a)
                                    {
                                        tree9.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree9.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                                else
                                {
                                    if (int.Parse(tree10.Text) == a)
                                    {
                                        tree10.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree10.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (int.Parse(tree2.Text) == a)
                    {
                        White();
                        tree2.BackColor = Color.Tomato;
                        Delay(1000);
                        if (tree13.Text != "")
                        {
                            tree2.Text = tree13.Text;
                            tree13.Visible = false;
                        }
                        else
                        {
                            tree2.Text = tree6.Text;
                            if (tree14.Text != "")
                            {
                                tree6.Text = tree14.Text;
                                tree14.Visible = false;
                            }
                            else
                            {
                                tree6.Visible = false;
                            }
                        }
                    }
                    else
                    {
                        White();
                        tree2.BackColor = Color.Tomato;
                        Delay(1000);
                        if (int.Parse(tree2.Text) > a)
                        {
                            if (int.Parse(tree5.Text) == a)
                            {
                                White();
                                tree5.BackColor = Color.Tomato;
                                Delay(1000);
                                if (tree11.Text != "")
                                {
                                    tree5.Text = tree11.Text;
                                    tree11.Visible = false;
                                }
                                else
                                {
                                    tree5.Text = tree12.Text;
                                    tree12.Visible = false;
                                }
                            }
                            else
                            {
                                White();
                                tree5.BackColor = Color.Tomato;
                                Delay(1000);
                                if (int.Parse(tree6.Text) > a)
                                {
                                    White();
                                    if (int.Parse(tree11.Text) == a)
                                    {
                                        tree11.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree11.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                                else
                                {
                                    White();
                                    if (int.Parse(tree12.Text) == a)
                                    {
                                        tree12.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree12.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (int.Parse(tree6.Text) == a)
                            {
                                White();
                                tree6.BackColor = Color.Tomato;
                                Delay(1000);
                                if (tree13.Text != "")
                                {
                                    tree6.Text = tree13.Text;
                                    tree13.Visible = false;
                                }
                                else
                                {
                                    tree6.Text = tree14.Text;
                                    tree14.Visible = false;
                                }
                            }
                            else
                            {
                                White();
                                tree6.BackColor = Color.Tomato;
                                Delay(1000);
                                if (int.Parse(tree7.Text) > a)
                                {
                                    White();
                                    if (int.Parse(tree13.Text) == a)
                                    {
                                        tree13.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree13.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                                else
                                {
                                    White();
                                    if (int.Parse(tree14.Text) == a)
                                    {
                                        tree14.BackColor = Color.Tomato;
                                        Delay(1000);
                                        tree14.Visible = false;
                                    }
                                    else
                                    {
                                        MessageBox.Show("해당 데이터가 트리에 존재하지 않습니다.");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Heightview();
        }

        void View()
        {
            tree7.Visible = false;
            tree8.Visible = false;
            tree9.Visible = false;
            tree10.Visible = false;
            tree11.Visible = false;
            tree12.Visible = false;
            tree13.Visible = false;
            tree14.Visible = false;
        }

        void White()
        {
            Root.BackColor = Color.White;
            tree1.BackColor = Color.White;
            tree2.BackColor = Color.White;
            tree3.BackColor = Color.White;
            tree4.BackColor = Color.White;
            tree5.BackColor = Color.White;
            tree6.BackColor = Color.White;
            tree7.BackColor = Color.White;
            tree8.BackColor = Color.White;
            tree9.BackColor = Color.White;
            tree10.BackColor = Color.White;
            tree11.BackColor = Color.White;
            tree12.BackColor = Color.White;
            tree13.BackColor = Color.White;
            tree14.BackColor = Color.White;
        }

        void Heightview()
        {
            if(tree7.Visible == false && tree8.Visible == false && tree9.Visible == false && tree10.Visible == false && tree11.Visible == false &&
                tree12.Visible == false && tree13.Visible == false && tree14.Visible == false)
            {
                height.Text = ("높이 = 3");
            }
            else
            {
                height.Text = ("높이 = 4");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private static DateTime Delay(int MS)
        {
            DateTime dateTime = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = dateTime.Add(duration);
            while(AfterWards >= dateTime)
            {
                Application.DoEvents();
                dateTime = DateTime.Now;
            }
            return DateTime.Now;
        }

        private void BST_Load(object sender, EventArgs e)
        {
            View();
        }
    }
}
