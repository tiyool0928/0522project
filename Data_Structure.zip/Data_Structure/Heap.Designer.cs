﻿namespace Data_Structure
{
    partial class Heap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Root = new System.Windows.Forms.Label();
            this.tree1 = new System.Windows.Forms.Label();
            this.tree2 = new System.Windows.Forms.Label();
            this.tree3 = new System.Windows.Forms.Label();
            this.tree4 = new System.Windows.Forms.Label();
            this.tree5 = new System.Windows.Forms.Label();
            this.tree6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Root
            // 
            this.Root.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Root.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Root.Location = new System.Drawing.Point(362, 39);
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(74, 68);
            this.Root.TabIndex = 3;
            this.Root.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree1
            // 
            this.tree1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree1.Location = new System.Drawing.Point(297, 128);
            this.tree1.Name = "tree1";
            this.tree1.Size = new System.Drawing.Size(74, 68);
            this.tree1.TabIndex = 4;
            this.tree1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree2
            // 
            this.tree2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree2.Location = new System.Drawing.Point(423, 128);
            this.tree2.Name = "tree2";
            this.tree2.Size = new System.Drawing.Size(74, 68);
            this.tree2.TabIndex = 5;
            this.tree2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree3
            // 
            this.tree3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree3.Location = new System.Drawing.Point(217, 214);
            this.tree3.Name = "tree3";
            this.tree3.Size = new System.Drawing.Size(74, 68);
            this.tree3.TabIndex = 6;
            this.tree3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree4
            // 
            this.tree4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree4.Location = new System.Drawing.Point(307, 214);
            this.tree4.Name = "tree4";
            this.tree4.Size = new System.Drawing.Size(74, 68);
            this.tree4.TabIndex = 7;
            this.tree4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree5
            // 
            this.tree5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree5.Location = new System.Drawing.Point(409, 214);
            this.tree5.Name = "tree5";
            this.tree5.Size = new System.Drawing.Size(74, 68);
            this.tree5.TabIndex = 8;
            this.tree5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree6
            // 
            this.tree6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree6.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree6.Location = new System.Drawing.Point(501, 214);
            this.tree6.Name = "tree6";
            this.tree6.Size = new System.Drawing.Size(74, 68);
            this.tree6.TabIndex = 9;
            this.tree6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Heap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tree6);
            this.Controls.Add(this.tree5);
            this.Controls.Add(this.tree4);
            this.Controls.Add(this.tree3);
            this.Controls.Add(this.tree2);
            this.Controls.Add(this.tree1);
            this.Controls.Add(this.Root);
            this.Name = "Heap";
            this.Text = "Heap";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label Root;
        private System.Windows.Forms.Label tree1;
        private System.Windows.Forms.Label tree2;
        private System.Windows.Forms.Label tree3;
        private System.Windows.Forms.Label tree4;
        private System.Windows.Forms.Label tree5;
        private System.Windows.Forms.Label tree6;
    }
}