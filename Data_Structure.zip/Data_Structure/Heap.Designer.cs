﻿namespace Data_Structure
{
    partial class Heap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tree14 = new System.Windows.Forms.Label();
            this.tree13 = new System.Windows.Forms.Label();
            this.tree12 = new System.Windows.Forms.Label();
            this.tree11 = new System.Windows.Forms.Label();
            this.tree10 = new System.Windows.Forms.Label();
            this.tree9 = new System.Windows.Forms.Label();
            this.tree8 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.NewBtn = new System.Windows.Forms.Button();
            this.tree7 = new System.Windows.Forms.Label();
            this.height = new System.Windows.Forms.Label();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.tree6 = new System.Windows.Forms.Label();
            this.tree5 = new System.Windows.Forms.Label();
            this.tree4 = new System.Windows.Forms.Label();
            this.tree3 = new System.Windows.Forms.Label();
            this.tree2 = new System.Windows.Forms.Label();
            this.tree1 = new System.Windows.Forms.Label();
            this.Root = new System.Windows.Forms.Label();
            this.PushBtn = new System.Windows.Forms.Button();
            this.DeleteLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tree14
            // 
            this.tree14.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree14.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree14.Location = new System.Drawing.Point(729, 311);
            this.tree14.Name = "tree14";
            this.tree14.Size = new System.Drawing.Size(74, 68);
            this.tree14.TabIndex = 62;
            this.tree14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree13
            // 
            this.tree13.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree13.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree13.Location = new System.Drawing.Point(646, 311);
            this.tree13.Name = "tree13";
            this.tree13.Size = new System.Drawing.Size(74, 68);
            this.tree13.TabIndex = 61;
            this.tree13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree12
            // 
            this.tree12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree12.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree12.Location = new System.Drawing.Point(566, 311);
            this.tree12.Name = "tree12";
            this.tree12.Size = new System.Drawing.Size(74, 68);
            this.tree12.TabIndex = 60;
            this.tree12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree11
            // 
            this.tree11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree11.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree11.Location = new System.Drawing.Point(486, 311);
            this.tree11.Name = "tree11";
            this.tree11.Size = new System.Drawing.Size(74, 68);
            this.tree11.TabIndex = 59;
            this.tree11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree10
            // 
            this.tree10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree10.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree10.Location = new System.Drawing.Point(389, 311);
            this.tree10.Name = "tree10";
            this.tree10.Size = new System.Drawing.Size(74, 68);
            this.tree10.TabIndex = 58;
            this.tree10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree9
            // 
            this.tree9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree9.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree9.Location = new System.Drawing.Point(309, 311);
            this.tree9.Name = "tree9";
            this.tree9.Size = new System.Drawing.Size(74, 68);
            this.tree9.TabIndex = 57;
            this.tree9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree8
            // 
            this.tree8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree8.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree8.Location = new System.Drawing.Point(229, 311);
            this.tree8.Name = "tree8";
            this.tree8.Size = new System.Drawing.Size(74, 68);
            this.tree8.TabIndex = 56;
            this.tree8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(951, 48);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 25);
            this.button1.TabIndex = 54;
            this.button1.Text = "나가기";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(81, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 19);
            this.label3.TabIndex = 53;
            this.label3.Text = "Heap (Max)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(873, 431);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 51;
            this.label1.Text = "숫자입력";
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(853, 446);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(92, 21);
            this.txtNum.TabIndex = 50;
            // 
            // NewBtn
            // 
            this.NewBtn.Location = new System.Drawing.Point(951, 443);
            this.NewBtn.Name = "NewBtn";
            this.NewBtn.Size = new System.Drawing.Size(92, 25);
            this.NewBtn.TabIndex = 49;
            this.NewBtn.Text = "삽입";
            this.NewBtn.UseVisualStyleBackColor = true;
            this.NewBtn.Click += new System.EventHandler(this.NewBtn_Click);
            // 
            // tree7
            // 
            this.tree7.BackColor = System.Drawing.Color.White;
            this.tree7.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree7.Location = new System.Drawing.Point(149, 311);
            this.tree7.Name = "tree7";
            this.tree7.Size = new System.Drawing.Size(74, 68);
            this.tree7.TabIndex = 48;
            this.tree7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // height
            // 
            this.height.AutoSize = true;
            this.height.Location = new System.Drawing.Point(754, 182);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(49, 12);
            this.height.TabIndex = 47;
            this.height.Text = "높이 = 3";
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Location = new System.Drawing.Point(951, 474);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(92, 25);
            this.DeleteBtn.TabIndex = 46;
            this.DeleteBtn.Text = "삭제";
            this.DeleteBtn.UseVisualStyleBackColor = true;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // tree6
            // 
            this.tree6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree6.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree6.Location = new System.Drawing.Point(627, 235);
            this.tree6.Name = "tree6";
            this.tree6.Size = new System.Drawing.Size(74, 68);
            this.tree6.TabIndex = 44;
            this.tree6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree5
            // 
            this.tree5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree5.Location = new System.Drawing.Point(523, 235);
            this.tree5.Name = "tree5";
            this.tree5.Size = new System.Drawing.Size(74, 68);
            this.tree5.TabIndex = 43;
            this.tree5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree4
            // 
            this.tree4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree4.Location = new System.Drawing.Point(340, 235);
            this.tree4.Name = "tree4";
            this.tree4.Size = new System.Drawing.Size(74, 68);
            this.tree4.TabIndex = 42;
            this.tree4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree3
            // 
            this.tree3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree3.Location = new System.Drawing.Point(233, 235);
            this.tree3.Name = "tree3";
            this.tree3.Size = new System.Drawing.Size(74, 68);
            this.tree3.TabIndex = 41;
            this.tree3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree2
            // 
            this.tree2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree2.Location = new System.Drawing.Point(494, 149);
            this.tree2.Name = "tree2";
            this.tree2.Size = new System.Drawing.Size(74, 68);
            this.tree2.TabIndex = 40;
            this.tree2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree1
            // 
            this.tree1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree1.Location = new System.Drawing.Point(368, 149);
            this.tree1.Name = "tree1";
            this.tree1.Size = new System.Drawing.Size(74, 68);
            this.tree1.TabIndex = 39;
            this.tree1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Root
            // 
            this.Root.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Root.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Root.Location = new System.Drawing.Point(433, 68);
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(74, 68);
            this.Root.TabIndex = 38;
            this.Root.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PushBtn
            // 
            this.PushBtn.Location = new System.Drawing.Point(951, 407);
            this.PushBtn.Name = "PushBtn";
            this.PushBtn.Size = new System.Drawing.Size(92, 25);
            this.PushBtn.TabIndex = 45;
            this.PushBtn.Text = "랜덤 채우기";
            this.PushBtn.UseVisualStyleBackColor = true;
            this.PushBtn.Click += new System.EventHandler(this.PushBtn_Click);
            // 
            // DeleteLabel
            // 
            this.DeleteLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DeleteLabel.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.DeleteLabel.Location = new System.Drawing.Point(729, 68);
            this.DeleteLabel.Name = "DeleteLabel";
            this.DeleteLabel.Size = new System.Drawing.Size(85, 68);
            this.DeleteLabel.TabIndex = 63;
            this.DeleteLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(746, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 12);
            this.label2.TabIndex = 64;
            this.label2.Text = "삭제된 값";
            // 
            // Heap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1102, 584);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.DeleteLabel);
            this.Controls.Add(this.tree14);
            this.Controls.Add(this.tree13);
            this.Controls.Add(this.tree12);
            this.Controls.Add(this.tree11);
            this.Controls.Add(this.tree10);
            this.Controls.Add(this.tree9);
            this.Controls.Add(this.tree8);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.NewBtn);
            this.Controls.Add(this.tree7);
            this.Controls.Add(this.height);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.PushBtn);
            this.Controls.Add(this.tree6);
            this.Controls.Add(this.tree5);
            this.Controls.Add(this.tree4);
            this.Controls.Add(this.tree3);
            this.Controls.Add(this.tree2);
            this.Controls.Add(this.tree1);
            this.Controls.Add(this.Root);
            this.Name = "Heap";
            this.Text = "Heap";
            this.Load += new System.EventHandler(this.Heap_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label tree14;
        private System.Windows.Forms.Label tree13;
        private System.Windows.Forms.Label tree12;
        private System.Windows.Forms.Label tree11;
        private System.Windows.Forms.Label tree10;
        private System.Windows.Forms.Label tree9;
        private System.Windows.Forms.Label tree8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button NewBtn;
        private System.Windows.Forms.Label tree7;
        private System.Windows.Forms.Label height;
        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Label tree6;
        private System.Windows.Forms.Label tree5;
        private System.Windows.Forms.Label tree4;
        private System.Windows.Forms.Label tree3;
        private System.Windows.Forms.Label tree2;
        private System.Windows.Forms.Label tree1;
        private System.Windows.Forms.Label Root;
        private System.Windows.Forms.Button PushBtn;
        private System.Windows.Forms.Label DeleteLabel;
        private System.Windows.Forms.Label label2;
    }
}