﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_Structure
{
    public partial class Stack : Form
    {
        Stack<int> stack = new Stack<int>(5);

        public Stack()
        {
            InitializeComponent();
        }

        private void PushBtn_Click(object sender, EventArgs e)
        {
            if(txtNum.Text == "")
            {
                MessageBox.Show("숫자를 입력해주세요");
            }
            else
            {
                int data = int.Parse(txtNum.Text);
                if (stack.Count > 4)
                {
                    MessageBox.Show("스택이 꽉찼습니다.");
                }
                else
                {
                    stack.Push(data);
                    StackView();
                    PushTop();
                }
            }
            
        }

        private void button1_Click(object sender, EventArgs e)      //pop
        {
            try
            {
                txtPop.Text = stack.Peek().ToString();
                stack.Pop();
            }
            catch (Exception)
            {
                MessageBox.Show("스택이 비어있습니다.");
            }
            
            StackView();
            PopTop();
            
        }

        void StackView()
        {
            int[] StackArray = stack.ToArray();

            Array.Resize(ref StackArray, 5);

            txtStack5.Text = (StackArray[0] == 0) ? "" : StackArray[0].ToString();
            txtStack4.Text = (StackArray[1] == 0) ? "" : StackArray[1].ToString();
            txtStack3.Text = (StackArray[2] == 0) ? "" : StackArray[2].ToString();
            txtStack2.Text = (StackArray[3] == 0) ? "" : StackArray[3].ToString();
            txtStack1.Text = (StackArray[4] == 0) ? "" : StackArray[4].ToString();

        }

        void PushTop()
        {
            top4.Top += 60;
            top3.Top += 60;
            top2.Top += 60;
            top1.Top += 60;
            top0.Top += 60;

            if(txtStack5.Text != "")
            {
                top0.Visible = true;
                if(txtStack4.Text != "")
                {
                    top1.Visible = true;
                    if(txtStack3.Text != "")
                    {
                        top2.Visible = true;
                        if(txtStack2.Text != "")
                        {
                            top3.Visible = true;
                            if(txtStack1.Text != "")
                            {
                                top4.Visible = true;
                            }
                        }
                    }
                }
            }
        }

        void PopTop()
        {
            top4.Top -= 60;
            top3.Top -= 60;
            top2.Top -= 60;
            top1.Top -= 60;
            top0.Top -= 60;

            if (txtStack1.Text == "")
            {
                top4.Visible = false;
                if (txtStack2.Text == "")
                {
                    top3.Visible = false;
                    if (txtStack3.Text == "")
                    {
                        top2.Visible = false;
                        if (txtStack4.Text == "")
                        {
                            top1.Visible = false;
                            if (txtStack5.Text == "")
                            {
                                top0.Visible = false;
                            }
                        }
                    }
                }
            }
        }

        private void Stack_Load(object sender, EventArgs e)
        {

            top4.Visible = false;
            top3.Visible = false;
            top2.Visible = false;
            top1.Visible = false;
            top0.Visible = false;

            
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
