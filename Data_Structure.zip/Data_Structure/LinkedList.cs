﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_Structure
{
    public partial class LinkedList : Form
    {
        public LinkedList()
        {
            InitializeComponent();
            MoveValue(n2addr, node1, nullnode1, nullnode2);
        }

        private void LinkedList_Load(object sender, EventArgs e)
        {
            View();
        }

        private void EnqueueBtn_Click(object sender, EventArgs e)
        {
            EnterNode();
        }

        private void DequeueBtn_Click(object sender, EventArgs e)
        {
            DeleteNode(txtDequeue.Text);
        }

        public void EnterNode()
        {
            if(node1.Text == "Null")
            {
                node2.Visible = true;
                n3addr.Visible = true;
                Link1.Visible = true;
                MoveValue(n3addr, node2, n2addr, node1);
                node1.Text = txtNum.Text;
                n2addr.Text = "Next = Null";
            }
            else
            {
                if (node2.Text == "Null")
                {
                    node3.Visible = true;
                    n4addr.Visible = true;
                    Link2.Visible = true;
                    MoveValue(n4addr, node3, n3addr, node2);
                    node2.Text = txtNum.Text;
                    n2addr.Text = "Next = Node2";
                    n3addr.Text = "Next = Null";
                }
                else
                {
                    if (node3.Text == "Null")
                    {
                        node4.Visible = true;
                        n5addr.Visible = true;
                        Link3.Visible = true; ;
                        MoveValue(n5addr, node4, n4addr, node3);
                        node3.Text = txtNum.Text;
                        n3addr.Text = "Next = Node3";
                        n4addr.Text = "Next = Null";
                    }
                    else
                    {
                        if (node4.Text == "Null")
                        {
                            node5.Visible = true;
                            nulladdr.Visible = true;
                            Link5.Visible = true; ;
                            MoveValue(nulladdr, node5, n5addr, node4);
                            node4.Text = txtNum.Text;
                            n4addr.Text = "Next = Node4";
                            n5addr.Text = "Next = Null";
                        }
                        else
                        {
                            if (node5.Text == "Null")
                            {
                                nullnode2.Visible = true;
                                nullnode1.Visible = true;
                                MoveValue(nullnode1, nullnode2, nulladdr, node5);
                                node5.Text = txtNum.Text;
                                n5addr.Text = "Next = Node5";
                                nulladdr.Text = "Next = Null";
                            }
                        }
                    }
                }
            }
        }

        public void DeleteNode(string Num)
        {
            DeleteNum.Text = Num;
            if (Num == node1.Text)
            {
                if (node2.Text == "Null")
                {
                    Link1.Visible = false;
                    MoveValue(n2addr, node1, n3addr, node2);
                    node2.Visible = false;
                    n3addr.Visible = false;
                }
                else if (node3.Text == "Null")
                {
                    Link2.Visible = false;
                    MoveValue(n2addr, node1, n3addr, node2);
                    MoveValue(n3addr, node2, n4addr, node3);
                    n2addr.Text = "Next = Node2";
                    node3.Visible = false;
                    n4addr.Visible = false;
                }
                else if (node4.Text == "Null")
                {
                    Link3.Visible = false;
                    MoveValue(n2addr, node1, n3addr, node2);
                    MoveValue(n3addr, node2, n4addr, node3);
                    MoveValue(n4addr, node3, n5addr, node4);
                    n2addr.Text = "Next = Node2";
                    n3addr.Text = "Next = Node3";
                    node4.Visible = false;
                    n5addr.Visible = false;
                }
                else if (node5.Text == "Null")
                {
                    Link4.Visible = false;
                    MoveValue(n2addr, node1, n3addr, node2);
                    MoveValue(n3addr, node2, n4addr, node3);
                    MoveValue(n4addr, node3, n5addr, node4);
                    MoveValue(n5addr, node4, nulladdr, node5);
                    n2addr.Text = "Next = Node2";
                    n3addr.Text = "Next = Node3";
                    n4addr.Text = "Next = Node4";
                    node5.Visible = false;
                    nulladdr.Visible = false;
                }
                else
                {
                    Link5.Visible = false;
                    MoveValue(n2addr, node1, n3addr, node2);
                    MoveValue(n3addr, node2, n4addr, node3);
                    MoveValue(n4addr, node3, n5addr, node4);
                    MoveValue(n5addr, node4, nulladdr, node5);
                    MoveValue(nulladdr, node5, nullnode1, nullnode1);
                    n2addr.Text = "Next = Node2";
                    n3addr.Text = "Next = Node3";
                    n4addr.Text = "Next = Node4";
                    n5addr.Text = "Next = Node5";
                    nullnode1.Visible = false;
                    nullnode2.Visible = false;
                }
            }
            else if (Num == node2.Text)
            {
                if (node3.Text == "Null")
                {
                    Link2.Visible = false;
                    MoveValue(n3addr, node2, n4addr, node3);
                    node3.Visible = false;
                    n4addr.Visible = false;
                }
                else if (node4.Text == "Null")
                {
                    Link3.Visible = false;
                    MoveValue(n3addr, node2, n4addr, node3);
                    MoveValue(n4addr, node3, n5addr, node4);
                    n3addr.Text = "Next = Node3";
                    node4.Visible = false;
                    n5addr.Visible = false;
                }
                else if (node5.Text == "Null")
                {
                    Link4.Visible = false;
                    MoveValue(n3addr, node2, n4addr, node3);
                    MoveValue(n4addr, node3, n5addr, node4);
                    MoveValue(n5addr, node4, nulladdr, node5);
                    n3addr.Text = "Next = Node3";
                    n4addr.Text = "Next = Node4";
                    node5.Visible = false;
                    nulladdr.Visible = false;
                }
                else
                {
                    Link5.Visible = false;
                    MoveValue(n3addr, node2, n4addr, node3);
                    MoveValue(n4addr, node3, n5addr, node4);
                    MoveValue(n5addr, node4, nulladdr, node5);
                    MoveValue(nulladdr, node5, nullnode1, nullnode2);
                    n3addr.Text = "Next = Node3";
                    n4addr.Text = "Next = Node4";
                    n5addr.Text = "Next = Node5";
                    nullnode1.Visible = false;
                    nullnode2.Visible = false;
                }
            }
            else if(Num == node3.Text)
            {
                if (node4.Text == "Null")
                {
                    Link3.Visible = false;
                    MoveValue(n4addr, node3, n5addr, node4);
                    node4.Visible = false;
                    n5addr.Visible = false;
                }
                else if (node5.Text == "Null")
                {
                    Link4.Visible = false;
                    MoveValue(n4addr, node3, n5addr, node4);
                    MoveValue(n5addr, node4, nulladdr, node5);
                    n4addr.Text = "Next = Node4";
                    node5.Visible = false;
                    nulladdr.Visible = false;
                }
                else
                {
                    Link5.Visible = false;
                    MoveValue(n4addr, node3, n5addr, node4);
                    MoveValue(n5addr, node4, nulladdr, node5);
                    MoveValue(nulladdr, node5, nullnode1, nullnode2);
                    n4addr.Text = "Next = Node4";
                    n5addr.Text = "Next = Node5";
                    nullnode1.Visible = false;
                    nullnode2.Visible = false;
                }
            }
            else if(Num == node4.Text)
            {
                if (node5.Text == "Null")
                {
                    Link4.Visible = false;
                    MoveValue(n5addr, node4, nulladdr, node5);
                    node5.Visible = false;
                    nulladdr.Visible = false;
                }
                else
                {
                    Link5.Visible = false;
                    MoveValue(n5addr, node4, nulladdr, node5);
                    MoveValue(nulladdr, node5, nullnode1, nullnode2);
                    n5addr.Text = "Next = Node5";
                    nullnode1.Visible = false;
                    nullnode2.Visible = false;
                }
            }
            else if(Num == node5.Text)
            {
                Link5.Visible = false;
                MoveValue(nulladdr, node5, nullnode1, nullnode2);
                nullnode1.Visible = false;
                nullnode2.Visible = false;
            }
            else
            {
                MessageBox.Show("해당 데이터가 리스트에 존재하지 않습니다.");
            }
        }

        public void View()
        {
            node2.Visible = false;
            node3.Visible = false;
            node4.Visible = false;
            node5.Visible = false;
            Link1.Visible = false;
            Link2.Visible = false;
            Link3.Visible = false;
            Link4.Visible = false;
            Link5.Visible = false;
            n3addr.Visible = false;
            n4addr.Visible = false;
            n5addr.Visible = false;
            nulladdr.Visible = false;
            nullnode1.Visible = false;
            nullnode2.Visible = false;
        }
        
        public void MoveValue(Label a,Label b,Label c,Label d)
        {
            a.Text = c.Text;
            b.Text = d.Text;
        }

        public void Change(Label a,Label b,Label c,Label d)
        {
            Label temp1 = new Label();
            Label temp2 = new Label();
            temp1.Location = a.Location;
            temp2.Location = b.Location;
            a.Location = c.Location;
            b.Location = d.Location;
            c.Location = temp1.Location;
            d.Location = temp2.Location;
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
