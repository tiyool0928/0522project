﻿namespace Data_Structure
{
    partial class BST
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Root = new System.Windows.Forms.Label();
            this.tree1 = new System.Windows.Forms.Label();
            this.tree2 = new System.Windows.Forms.Label();
            this.tree3 = new System.Windows.Forms.Label();
            this.tree4 = new System.Windows.Forms.Label();
            this.tree5 = new System.Windows.Forms.Label();
            this.tree6 = new System.Windows.Forms.Label();
            this.PushBtn = new System.Windows.Forms.Button();
            this.DeleteBtn = new System.Windows.Forms.Button();
            this.height = new System.Windows.Forms.Label();
            this.tree7 = new System.Windows.Forms.Label();
            this.NewBtn = new System.Windows.Forms.Button();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SearchBtn = new System.Windows.Forms.Button();
            this.tree8 = new System.Windows.Forms.Label();
            this.tree9 = new System.Windows.Forms.Label();
            this.tree10 = new System.Windows.Forms.Label();
            this.tree11 = new System.Windows.Forms.Label();
            this.tree12 = new System.Windows.Forms.Label();
            this.tree13 = new System.Windows.Forms.Label();
            this.tree14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Root
            // 
            this.Root.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Root.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Root.Location = new System.Drawing.Point(414, 53);
            this.Root.Name = "Root";
            this.Root.Size = new System.Drawing.Size(74, 68);
            this.Root.TabIndex = 3;
            this.Root.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree1
            // 
            this.tree1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree1.Location = new System.Drawing.Point(349, 134);
            this.tree1.Name = "tree1";
            this.tree1.Size = new System.Drawing.Size(74, 68);
            this.tree1.TabIndex = 4;
            this.tree1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree2
            // 
            this.tree2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree2.Location = new System.Drawing.Point(475, 134);
            this.tree2.Name = "tree2";
            this.tree2.Size = new System.Drawing.Size(74, 68);
            this.tree2.TabIndex = 5;
            this.tree2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree3
            // 
            this.tree3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree3.Location = new System.Drawing.Point(214, 220);
            this.tree3.Name = "tree3";
            this.tree3.Size = new System.Drawing.Size(74, 68);
            this.tree3.TabIndex = 6;
            this.tree3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree4
            // 
            this.tree4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree4.Location = new System.Drawing.Point(321, 220);
            this.tree4.Name = "tree4";
            this.tree4.Size = new System.Drawing.Size(74, 68);
            this.tree4.TabIndex = 7;
            this.tree4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree5
            // 
            this.tree5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree5.Location = new System.Drawing.Point(504, 220);
            this.tree5.Name = "tree5";
            this.tree5.Size = new System.Drawing.Size(74, 68);
            this.tree5.TabIndex = 8;
            this.tree5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree6
            // 
            this.tree6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree6.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree6.Location = new System.Drawing.Point(608, 220);
            this.tree6.Name = "tree6";
            this.tree6.Size = new System.Drawing.Size(74, 68);
            this.tree6.TabIndex = 9;
            this.tree6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PushBtn
            // 
            this.PushBtn.Location = new System.Drawing.Point(932, 392);
            this.PushBtn.Name = "PushBtn";
            this.PushBtn.Size = new System.Drawing.Size(92, 25);
            this.PushBtn.TabIndex = 10;
            this.PushBtn.Text = "랜덤 채우기";
            this.PushBtn.UseVisualStyleBackColor = true;
            this.PushBtn.Click += new System.EventHandler(this.PushBtn_Click);
            // 
            // DeleteBtn
            // 
            this.DeleteBtn.Location = new System.Drawing.Point(932, 484);
            this.DeleteBtn.Name = "DeleteBtn";
            this.DeleteBtn.Size = new System.Drawing.Size(92, 25);
            this.DeleteBtn.TabIndex = 13;
            this.DeleteBtn.Text = "삭제";
            this.DeleteBtn.UseVisualStyleBackColor = true;
            this.DeleteBtn.Click += new System.EventHandler(this.DeleteBtn_Click);
            // 
            // height
            // 
            this.height.AutoSize = true;
            this.height.Location = new System.Drawing.Point(735, 167);
            this.height.Name = "height";
            this.height.Size = new System.Drawing.Size(49, 12);
            this.height.TabIndex = 16;
            this.height.Text = "높이 = 3";
            // 
            // tree7
            // 
            this.tree7.BackColor = System.Drawing.Color.White;
            this.tree7.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree7.Location = new System.Drawing.Point(130, 296);
            this.tree7.Name = "tree7";
            this.tree7.Size = new System.Drawing.Size(74, 68);
            this.tree7.TabIndex = 17;
            this.tree7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NewBtn
            // 
            this.NewBtn.Location = new System.Drawing.Point(932, 452);
            this.NewBtn.Name = "NewBtn";
            this.NewBtn.Size = new System.Drawing.Size(92, 25);
            this.NewBtn.TabIndex = 18;
            this.NewBtn.Text = "삽입";
            this.NewBtn.UseVisualStyleBackColor = true;
            this.NewBtn.Click += new System.EventHandler(this.NewBtn_Click);
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(834, 456);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(92, 21);
            this.txtNum.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(855, 441);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 23;
            this.label1.Text = "숫자입력";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(75, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(168, 19);
            this.label3.TabIndex = 28;
            this.label3.Text = "BinarySearchTree";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(932, 33);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 25);
            this.button1.TabIndex = 29;
            this.button1.Text = "나가기";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // SearchBtn
            // 
            this.SearchBtn.Location = new System.Drawing.Point(932, 423);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(92, 25);
            this.SearchBtn.TabIndex = 30;
            this.SearchBtn.Text = "탐색";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // tree8
            // 
            this.tree8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree8.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree8.Location = new System.Drawing.Point(210, 296);
            this.tree8.Name = "tree8";
            this.tree8.Size = new System.Drawing.Size(74, 68);
            this.tree8.TabIndex = 31;
            this.tree8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree9
            // 
            this.tree9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree9.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree9.Location = new System.Drawing.Point(290, 296);
            this.tree9.Name = "tree9";
            this.tree9.Size = new System.Drawing.Size(74, 68);
            this.tree9.TabIndex = 32;
            this.tree9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree10
            // 
            this.tree10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree10.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree10.Location = new System.Drawing.Point(370, 296);
            this.tree10.Name = "tree10";
            this.tree10.Size = new System.Drawing.Size(74, 68);
            this.tree10.TabIndex = 33;
            this.tree10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree11
            // 
            this.tree11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree11.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree11.Location = new System.Drawing.Point(467, 296);
            this.tree11.Name = "tree11";
            this.tree11.Size = new System.Drawing.Size(74, 68);
            this.tree11.TabIndex = 34;
            this.tree11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree12
            // 
            this.tree12.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree12.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree12.Location = new System.Drawing.Point(547, 296);
            this.tree12.Name = "tree12";
            this.tree12.Size = new System.Drawing.Size(74, 68);
            this.tree12.TabIndex = 35;
            this.tree12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree13
            // 
            this.tree13.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree13.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree13.Location = new System.Drawing.Point(627, 296);
            this.tree13.Name = "tree13";
            this.tree13.Size = new System.Drawing.Size(74, 68);
            this.tree13.TabIndex = 36;
            this.tree13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tree14
            // 
            this.tree14.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tree14.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tree14.Location = new System.Drawing.Point(710, 296);
            this.tree14.Name = "tree14";
            this.tree14.Size = new System.Drawing.Size(74, 68);
            this.tree14.TabIndex = 37;
            this.tree14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BST
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 614);
            this.Controls.Add(this.tree14);
            this.Controls.Add(this.tree13);
            this.Controls.Add(this.tree12);
            this.Controls.Add(this.tree11);
            this.Controls.Add(this.tree10);
            this.Controls.Add(this.tree9);
            this.Controls.Add(this.tree8);
            this.Controls.Add(this.SearchBtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.NewBtn);
            this.Controls.Add(this.tree7);
            this.Controls.Add(this.height);
            this.Controls.Add(this.DeleteBtn);
            this.Controls.Add(this.PushBtn);
            this.Controls.Add(this.tree6);
            this.Controls.Add(this.tree5);
            this.Controls.Add(this.tree4);
            this.Controls.Add(this.tree3);
            this.Controls.Add(this.tree2);
            this.Controls.Add(this.tree1);
            this.Controls.Add(this.Root);
            this.Name = "BST";
            this.Text = "삽입";
            this.Load += new System.EventHandler(this.BST_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Root;
        private System.Windows.Forms.Label tree1;
        private System.Windows.Forms.Label tree2;
        private System.Windows.Forms.Label tree3;
        private System.Windows.Forms.Label tree4;
        private System.Windows.Forms.Label tree5;
        private System.Windows.Forms.Label tree6;
        private System.Windows.Forms.Button PushBtn;
        private System.Windows.Forms.Button DeleteBtn;
        private System.Windows.Forms.Label height;
        private System.Windows.Forms.Label tree7;
        private System.Windows.Forms.Button NewBtn;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button SearchBtn;
        private System.Windows.Forms.Label tree8;
        private System.Windows.Forms.Label tree9;
        private System.Windows.Forms.Label tree10;
        private System.Windows.Forms.Label tree11;
        private System.Windows.Forms.Label tree12;
        private System.Windows.Forms.Label tree13;
        private System.Windows.Forms.Label tree14;
    }
}