﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_Structure
{
    public partial class Heap : Form
    {
        List<int> heap = new List<int>(10);

        public Heap()
        {
            InitializeComponent();
            Circular();
        }

        private void PushBtn_Click(object sender, EventArgs e)
        {
            BubbleSort();
        }

        private void NewBtn_Click(object sender, EventArgs e)
        {
            newTree(int.Parse(txtNum.Text));
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            try
            {
                DeleteTree();
            }
            catch (Exception)
            {
                MessageBox.Show("삭제가 완료되었습니다.");
            }
        }

        void BubbleSort()
        {
            Random random = new Random();
            if (Root.Text == "")
            {
                int data = random.Next(70, 99);
                Root.Text = Convert.ToString(data);
            }
            else
            {
                if(tree1.Text == "")
                {
                    int data = random.Next(30, 69);
                    tree1.Text = Convert.ToString(data);
                }
                else
                {
                    if(tree2.Text == "")
                    {
                        int data = random.Next(30, 69);
                        tree2.Text = Convert.ToString(data);
                    }
                    else
                    {
                        if(tree3.Text == "")
                        {
                            int data = random.Next(1, 29);
                            tree3.Text = Convert.ToString(data);
                        }
                        else
                        {
                            if(tree4.Text == "")
                            {
                                int data = random.Next(1, 29);
                                tree4.Text = Convert.ToString(data);
                            }
                            else
                            {
                                if (tree5.Text == "")
                                {
                                    int data = random.Next(1, 29);
                                    tree5.Text = Convert.ToString(data);
                                }
                                else
                                {
                                    if (tree6.Text == "")
                                    {
                                        int data = random.Next(1, 29);
                                        tree6.Text = Convert.ToString(data);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public void newTree(int a)
        {
            if(tree7.Text == "")
            {
                White();
                tree7.Visible = true;
                tree7.Text = txtNum.Text;
                tree7.BackColor = Color.Tomato;
                Delay(1000);
                if(a > int.Parse(tree3.Text))
                {
                    White();
                    sort(tree7, tree3);
                    tree3.BackColor = Color.Tomato;
                    Delay(1000);
                    if (a > int.Parse(tree1.Text))
                    {
                        White();
                        sort(tree3, tree1);
                        tree1.BackColor = Color.Tomato;
                        Delay(1000);
                        if (a > int.Parse(Root.Text))
                        {
                            White();
                            sort(tree1, Root);
                            Root.BackColor = Color.Tomato;
                        }
                    }
                }
            }
            else
            {
                if (tree8.Text == "")
                {
                    White();
                    tree8.Visible = true;
                    tree8.Text = txtNum.Text;
                    tree8.BackColor = Color.Tomato;
                    Delay(1000);
                    if (a > int.Parse(tree3.Text))
                    {
                        White();
                        sort(tree8, tree3);
                        tree3.BackColor = Color.Tomato;
                        Delay(1000);
                        if (a > int.Parse(tree1.Text))
                        {
                            White();
                            sort(tree3, tree1);
                            tree1.BackColor = Color.Tomato;
                            Delay(1000);
                            if (a > int.Parse(Root.Text))
                            {
                                White();
                                sort(tree1, Root);
                                Root.BackColor = Color.Tomato;
                            }
                        }
                    }
                }
                else
                {
                    if (tree9.Text == "")
                    {
                        White();
                        tree9.Visible = true;
                        tree9.Text = txtNum.Text;
                        tree9.BackColor = Color.Tomato;
                        Delay(1000);
                        if (a > int.Parse(tree4.Text))
                        {
                            White();
                            sort(tree9, tree4);
                            tree4.BackColor = Color.Tomato;
                            Delay(1000);
                            if (a > int.Parse(tree1.Text))
                            {
                                White();
                                sort(tree4, tree1);
                                tree1.BackColor = Color.Tomato;
                                Delay(1000);
                                if (a > int.Parse(Root.Text))
                                {
                                    White();
                                    sort(tree1, Root);
                                    Root.BackColor = Color.Tomato;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (tree10.Text == "")
                        {
                            White();
                            tree10.Visible = true;
                            tree10.Text = txtNum.Text;
                            tree10.BackColor = Color.Tomato;
                            Delay(1000);
                            if (a > int.Parse(tree4.Text))
                            {
                                White();
                                sort(tree10, tree4);
                                tree4.BackColor = Color.Tomato;
                                Delay(1000);
                                if (a > int.Parse(tree1.Text))
                                {
                                    White();
                                    sort(tree4, tree1);
                                    tree1.BackColor = Color.Tomato;
                                    Delay(1000);
                                    if (a > int.Parse(Root.Text))
                                    {
                                        White();
                                        sort(tree1, Root);
                                        Root.BackColor = Color.Tomato;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (tree11.Text == "")
                            {
                                White();
                                tree11.Visible = true;
                                tree11.Text = txtNum.Text;
                                tree11.BackColor = Color.Tomato;
                                Delay(1000);
                                if (a > int.Parse(tree5.Text))
                                {
                                    White();
                                    sort(tree11, tree5);
                                    tree5.BackColor = Color.Tomato;
                                    Delay(1000);
                                    if (a > int.Parse(tree2.Text))
                                    {
                                        White();
                                        sort(tree5, tree2);
                                        tree2.BackColor = Color.Tomato;
                                        Delay(1000);
                                        if (a > int.Parse(Root.Text))
                                        {
                                            White();
                                            sort(tree2, Root);
                                            Root.BackColor = Color.Tomato;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (tree12.Text == "")
                                {
                                    White();
                                    tree12.Visible = true;
                                    tree12.Text = txtNum.Text;
                                    tree12.BackColor = Color.Tomato;
                                    Delay(1000);
                                    if (a > int.Parse(tree5.Text))
                                    {
                                        White();
                                        sort(tree12, tree5);
                                        tree5.BackColor = Color.Tomato;
                                        Delay(1000);
                                        if (a > int.Parse(tree2.Text))
                                        {
                                            White();
                                            sort(tree5, tree2);
                                            tree2.BackColor = Color.Tomato;
                                            Delay(1000);
                                            if (a > int.Parse(Root.Text))
                                            {
                                                White();
                                                sort(tree2, Root);
                                                Root.BackColor = Color.Tomato;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (tree13.Text == "")
                                    {
                                        White();
                                        tree13.Visible = true;
                                        tree13.Text = txtNum.Text;
                                        tree13.BackColor = Color.Tomato;
                                        Delay(1000);
                                        if (a > int.Parse(tree6.Text))
                                        {
                                            White();
                                            sort(tree13, tree6);
                                            tree6.BackColor = Color.Tomato;
                                            Delay(1000);
                                            if (a > int.Parse(tree2.Text))
                                            {
                                                White();
                                                sort(tree6, tree2);
                                                tree2.BackColor = Color.Tomato;
                                                Delay(1000);
                                                if (a > int.Parse(Root.Text))
                                                {
                                                    White();
                                                    sort(tree2, Root);
                                                    Root.BackColor = Color.Tomato;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (tree14.Text == "")
                                        {
                                            White();
                                            tree14.Visible = true;
                                            tree14.Text = txtNum.Text;
                                            tree14.BackColor = Color.Tomato;
                                            Delay(1000);
                                            if (a > int.Parse(tree6.Text))
                                            {
                                                White();
                                                sort(tree14, tree6);
                                                tree6.BackColor = Color.Tomato;
                                                Delay(1000);
                                                if (a > int.Parse(tree2.Text))
                                                {
                                                    White();
                                                    sort(tree6, tree2);
                                                    tree2.BackColor = Color.Tomato;
                                                    Delay(1000);
                                                    if (a > int.Parse(Root.Text))
                                                    {
                                                        White();
                                                        sort(tree2, Root);
                                                        Root.BackColor = Color.Tomato;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Heightview();
        }

        public void DeleteTree()
        {
            White();
            Root.BackColor = Color.Tomato;
            Delay(1000);
            DeleteLabel.Text = Root.Text;
            label2.Visible = true;
            DeleteLabel.Visible = true;
            if(tree14.Text != "")
            {
                Root.Text = tree14.Text;
                tree14.Text = "";
                tree14.Visible = false;
                Delay(1000);
                DeleteSort();
            }
            else
            {
                if (tree13.Text != "")
                {
                    Root.Text = tree13.Text;
                    tree13.Text = "";
                    tree13.Visible = false;
                    Delay(1000);
                    DeleteSort();
                }
                else
                {
                    if (tree12.Text != "")
                    {
                        Root.Text = tree12.Text;
                        tree12.Text = "";
                        tree12.Visible = false;
                        Delay(1000);
                        DeleteSort();
                    }
                    else
                    {
                        if (tree11.Text != "")
                        {
                            Root.Text = tree11.Text;
                            tree11.Text = "";
                            tree11.Visible = false;
                            Delay(1000);
                            DeleteSort();
                        }
                        else
                        {
                            if (tree10.Text != "")
                            {
                                Root.Text = tree10.Text;
                                tree10.Text = "";
                                tree10.Visible = false;
                                Delay(1000);
                                DeleteSort();
                            }
                            else
                            {
                                if (tree9.Text != "")
                                {
                                    Root.Text = tree9.Text;
                                    tree9.Text = "";
                                    tree9.Visible = false;
                                    Delay(1000);
                                    DeleteSort();
                                }
                                else
                                {
                                    if (tree8.Text != "")
                                    {
                                        Root.Text = tree8.Text;
                                        tree8.Text = "";
                                        tree8.Visible = false;
                                        Delay(1000);
                                        DeleteSort();
                                    }
                                    else
                                    {
                                        if (tree7.Text != "")
                                        {
                                            Root.Text = tree7.Text;
                                            tree7.Text = "";
                                            tree7.Visible = false;
                                            Delay(1000);
                                            DeleteSort();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Heightview();
        }

        public void sort(Label a,Label b)
        {
            string temp = a.Text;
            a.Text = b.Text;
            b.Text = temp;
        }

        public void DeleteSort()
        {
            if (int.Parse(tree1.Text) > int.Parse(tree2.Text))
            {
                if (int.Parse(Root.Text) < int.Parse(tree1.Text))
                {
                    White();
                    sort(tree1, Root);
                    tree1.BackColor = Color.Tomato;
                    Delay(1000);
                    if (int.Parse(tree3.Text) > int.Parse(tree4.Text))
                    {
                        if (int.Parse(tree1.Text) < int.Parse(tree3.Text))
                        {
                            White();
                            sort(tree3, tree1);
                            tree3.BackColor = Color.Tomato;
                            Delay(1000);
                            if (int.Parse(tree7.Text) > int.Parse(tree8.Text))
                            {
                                if (int.Parse(tree3.Text) < int.Parse(tree7.Text))
                                {
                                    White();
                                    sort(tree7, tree3);
                                    tree7.BackColor = Color.Tomato;
                                }
                            }
                            else
                            {
                                if (int.Parse(tree3.Text) < int.Parse(tree8.Text))
                                {
                                    White();
                                    sort(tree8, tree3);
                                    tree8.BackColor = Color.Tomato;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (int.Parse(tree1.Text) < int.Parse(tree4.Text))
                        {
                            White();
                            sort(tree4, tree1);
                            tree4.BackColor = Color.Tomato;
                            Delay(1000);
                            if (int.Parse(tree9.Text) > int.Parse(tree10.Text))
                            {
                                if (int.Parse(tree4.Text) < int.Parse(tree9.Text))
                                {
                                    White();
                                    sort(tree9, tree4);
                                    tree9.BackColor = Color.Tomato;
                                }
                            }
                            else
                            {
                                if (int.Parse(tree4.Text) < int.Parse(tree10.Text))
                                {
                                    White();
                                    sort(tree10, tree4);
                                    tree10.BackColor = Color.Tomato;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                if (int.Parse(Root.Text) < int.Parse(tree2.Text))
                {
                    White();
                    sort(tree2, Root);
                    tree2.BackColor = Color.Tomato;
                    Delay(1000);
                    if (int.Parse(tree5.Text) > int.Parse(tree6.Text))
                    {
                        if (int.Parse(tree2.Text) < int.Parse(tree5.Text))
                        {
                            White();
                            sort(tree5, tree2);
                            tree5.BackColor = Color.Tomato;
                            Delay(1000);
                            if (int.Parse(tree11.Text) > int.Parse(tree12.Text))
                            {
                                if (int.Parse(tree5.Text) < int.Parse(tree11.Text))
                                {
                                    White();
                                    sort(tree11, tree5);
                                    tree11.BackColor = Color.Tomato;
                                }
                            }
                            else
                            {
                                if (int.Parse(tree5.Text) < int.Parse(tree12.Text))
                                {
                                    White();
                                    sort(tree12, tree5);
                                    tree12.BackColor = Color.Tomato;
                                }
                            }
                        }
                    }
                    else
                    {
                        if (int.Parse(tree2.Text) < int.Parse(tree6.Text))
                        {
                            White();
                            sort(tree6, tree2);
                            tree6.BackColor = Color.Tomato;
                            Delay(1000);
                            if (int.Parse(tree13.Text) > int.Parse(tree14.Text))
                            {
                                if (int.Parse(tree6.Text) < int.Parse(tree13.Text))
                                {
                                    White();
                                    sort(tree13, tree6);
                                    tree13.BackColor = Color.Tomato;
                                }
                            }
                            else
                            {
                                if (int.Parse(tree6.Text) < int.Parse(tree14.Text))
                                {
                                    White();
                                    sort(tree14, tree6);
                                    tree14.BackColor = Color.Tomato;
                                }
                            }
                        }
                    }
                }
            }
        }

        void Circular()
        {
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, Root.Width, Root.Height);
            Root.Region = new Region(path);
            tree1.Region = new Region(path);
            tree2.Region = new Region(path);
            tree3.Region = new Region(path);
            tree4.Region = new Region(path);
            tree5.Region = new Region(path);
            tree6.Region = new Region(path);
            tree7.Region = new Region(path);
            tree8.Region = new Region(path);
            tree9.Region = new Region(path);
            tree10.Region = new Region(path);
            tree11.Region = new Region(path);
            tree12.Region = new Region(path);
            tree13.Region = new Region(path);
            tree14.Region = new Region(path);
            DeleteLabel.Region = new Region(path);
        }

        void View()
        {
            tree7.Visible = false;
            tree8.Visible = false;
            tree9.Visible = false;
            tree10.Visible = false;
            tree11.Visible = false;
            tree12.Visible = false;
            tree13.Visible = false;
            tree14.Visible = false;
            DeleteLabel.Visible = false;
            label2.Visible = false;             //삭제된 값 텍스트
        }

        void White()
        {
            Root.BackColor = Color.White;
            tree1.BackColor = Color.White;
            tree2.BackColor = Color.White;
            tree3.BackColor = Color.White;
            tree4.BackColor = Color.White;
            tree5.BackColor = Color.White;
            tree6.BackColor = Color.White;
            tree7.BackColor = Color.White;
            tree8.BackColor = Color.White;
            tree9.BackColor = Color.White;
            tree10.BackColor = Color.White;
            tree11.BackColor = Color.White;
            tree12.BackColor = Color.White;
            tree13.BackColor = Color.White;
            tree14.BackColor = Color.White;
        }

        void Heightview()
        {
            if (tree7.Visible == false && tree8.Visible == false && tree9.Visible == false && tree10.Visible == false && tree11.Visible == false &&
                tree12.Visible == false && tree13.Visible == false && tree14.Visible == false)
            {
                height.Text = ("높이 = 3");
            }
            else
            {
                height.Text = ("높이 = 4");
            }
        }

        private static DateTime Delay(int MS)
        {
            DateTime dateTime = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = dateTime.Add(duration);
            while (AfterWards >= dateTime)
            {
                Application.DoEvents();
                dateTime = DateTime.Now;
            }
            return DateTime.Now;
        }

        private void Heap_Load(object sender, EventArgs e)
        {
            View();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
