﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_Structure
{
    public partial class Heap : Form
    {
        public Heap()
        {
            InitializeComponent();
            Circular();
        }

        void Circular()
        {
            var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddEllipse(0, 0, Root.Width, Root.Height);
            Root.Region = new Region(path);
            tree1.Region = new Region(path);
            tree2.Region = new Region(path);
            tree3.Region = new Region(path);
            tree4.Region = new Region(path);
            tree5.Region = new Region(path);
            tree6.Region = new Region(path);

        }
    }
}
