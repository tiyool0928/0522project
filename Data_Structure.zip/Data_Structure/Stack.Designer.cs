﻿namespace Data_Structure
{
    partial class Stack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PushBtn = new System.Windows.Forms.Button();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txtStack1 = new System.Windows.Forms.TextBox();
            this.txtStack2 = new System.Windows.Forms.TextBox();
            this.txtStack3 = new System.Windows.Forms.TextBox();
            this.txtStack4 = new System.Windows.Forms.TextBox();
            this.txtStack5 = new System.Windows.Forms.TextBox();
            this.txtPop = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.top4 = new System.Windows.Forms.Label();
            this.top3 = new System.Windows.Forms.Label();
            this.top2 = new System.Windows.Forms.Label();
            this.top1 = new System.Windows.Forms.Label();
            this.top0 = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PushBtn
            // 
            this.PushBtn.Location = new System.Drawing.Point(38, 304);
            this.PushBtn.Name = "PushBtn";
            this.PushBtn.Size = new System.Drawing.Size(92, 25);
            this.PushBtn.TabIndex = 0;
            this.PushBtn.Text = "Push";
            this.PushBtn.UseVisualStyleBackColor = true;
            this.PushBtn.Click += new System.EventHandler(this.PushBtn_Click);
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(38, 277);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(92, 21);
            this.txtNum.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "숫자 입력";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(644, 304);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 25);
            this.button1.TabIndex = 3;
            this.button1.Text = "Pop";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtStack1
            // 
            this.txtStack1.BackColor = System.Drawing.SystemColors.Window;
            this.txtStack1.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtStack1.Location = new System.Drawing.Point(326, 290);
            this.txtStack1.Multiline = true;
            this.txtStack1.Name = "txtStack1";
            this.txtStack1.Size = new System.Drawing.Size(102, 43);
            this.txtStack1.TabIndex = 4;
            this.txtStack1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtStack2
            // 
            this.txtStack2.BackColor = System.Drawing.SystemColors.Window;
            this.txtStack2.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtStack2.Location = new System.Drawing.Point(326, 230);
            this.txtStack2.Multiline = true;
            this.txtStack2.Name = "txtStack2";
            this.txtStack2.Size = new System.Drawing.Size(102, 43);
            this.txtStack2.TabIndex = 5;
            this.txtStack2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtStack3
            // 
            this.txtStack3.BackColor = System.Drawing.SystemColors.Window;
            this.txtStack3.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtStack3.Location = new System.Drawing.Point(326, 170);
            this.txtStack3.Multiline = true;
            this.txtStack3.Name = "txtStack3";
            this.txtStack3.Size = new System.Drawing.Size(102, 43);
            this.txtStack3.TabIndex = 6;
            this.txtStack3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtStack4
            // 
            this.txtStack4.BackColor = System.Drawing.SystemColors.Window;
            this.txtStack4.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtStack4.Location = new System.Drawing.Point(326, 110);
            this.txtStack4.Multiline = true;
            this.txtStack4.Name = "txtStack4";
            this.txtStack4.Size = new System.Drawing.Size(102, 43);
            this.txtStack4.TabIndex = 7;
            this.txtStack4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtStack5
            // 
            this.txtStack5.BackColor = System.Drawing.SystemColors.Window;
            this.txtStack5.Font = new System.Drawing.Font("굴림", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtStack5.Location = new System.Drawing.Point(326, 50);
            this.txtStack5.Multiline = true;
            this.txtStack5.Name = "txtStack5";
            this.txtStack5.Size = new System.Drawing.Size(102, 43);
            this.txtStack5.TabIndex = 8;
            this.txtStack5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtPop
            // 
            this.txtPop.Location = new System.Drawing.Point(644, 277);
            this.txtPop.Name = "txtPop";
            this.txtPop.ReadOnly = true;
            this.txtPop.Size = new System.Drawing.Size(92, 21);
            this.txtPop.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(667, 262);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 12);
            this.label2.TabIndex = 10;
            this.label2.Text = "pop된 값";
            // 
            // top4
            // 
            this.top4.AutoSize = true;
            this.top4.Location = new System.Drawing.Point(452, -236);
            this.top4.Name = "top4";
            this.top4.Size = new System.Drawing.Size(11, 12);
            this.top4.TabIndex = 11;
            this.top4.Text = "4";
            // 
            // top3
            // 
            this.top3.AutoSize = true;
            this.top3.Location = new System.Drawing.Point(452, -176);
            this.top3.Name = "top3";
            this.top3.Size = new System.Drawing.Size(11, 12);
            this.top3.TabIndex = 12;
            this.top3.Text = "3";
            // 
            // top2
            // 
            this.top2.AutoSize = true;
            this.top2.Location = new System.Drawing.Point(452, -116);
            this.top2.Name = "top2";
            this.top2.Size = new System.Drawing.Size(11, 12);
            this.top2.TabIndex = 13;
            this.top2.Text = "2";
            // 
            // top1
            // 
            this.top1.AutoSize = true;
            this.top1.Location = new System.Drawing.Point(452, -56);
            this.top1.Name = "top1";
            this.top1.Size = new System.Drawing.Size(11, 12);
            this.top1.TabIndex = 14;
            this.top1.Text = "1";
            // 
            // top0
            // 
            this.top0.AutoSize = true;
            this.top0.Location = new System.Drawing.Point(452, 4);
            this.top0.Name = "top0";
            this.top0.Size = new System.Drawing.Size(11, 12);
            this.top0.TabIndex = 15;
            this.top0.Text = "0";
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(644, 30);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(92, 25);
            this.exitBtn.TabIndex = 16;
            this.exitBtn.Text = "나가기";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(55, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 19);
            this.label3.TabIndex = 17;
            this.label3.Text = "Stack";
            // 
            // Stack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 423);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.top0);
            this.Controls.Add(this.top1);
            this.Controls.Add(this.top2);
            this.Controls.Add(this.top3);
            this.Controls.Add(this.top4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtPop);
            this.Controls.Add(this.txtStack5);
            this.Controls.Add(this.txtStack4);
            this.Controls.Add(this.txtStack3);
            this.Controls.Add(this.txtStack2);
            this.Controls.Add(this.txtStack1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.PushBtn);
            this.Name = "Stack";
            this.Text = "Stack";
            this.Load += new System.EventHandler(this.Stack_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button PushBtn;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtStack1;
        private System.Windows.Forms.TextBox txtStack2;
        private System.Windows.Forms.TextBox txtStack3;
        private System.Windows.Forms.TextBox txtStack4;
        private System.Windows.Forms.TextBox txtStack5;
        private System.Windows.Forms.TextBox txtPop;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label top4;
        private System.Windows.Forms.Label top3;
        private System.Windows.Forms.Label top2;
        private System.Windows.Forms.Label top1;
        private System.Windows.Forms.Label top0;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label label3;
    }
}