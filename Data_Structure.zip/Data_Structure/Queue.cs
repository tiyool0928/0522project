﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Data_Structure
{
    public partial class Queue : Form
    {
        Queue<int> queue = new Queue<int>(5);
        public Queue()
        {
            InitializeComponent();
        }

        private void EnqueueBtn_Click(object sender, EventArgs e)
        {
            if (queue.Count > 4)
            {
                MessageBox.Show("큐가 꽉찼습니다.");
            }
            else
            {
                int data = int.Parse(txtNum.Text);
                queue.Enqueue(data);
                QueueView();
            }
        }

        private void DequeueBtn_Click(object sender, EventArgs e)
        {
            try
            {
                txtDequeue.Text = queue.Peek().ToString();
                queue.Dequeue();
                QueueView();
            }
            catch (Exception)
            {

                MessageBox.Show("큐가 비어있습니다.");
            }
            
        }

        void QueueView()
        {
            int[] QueueArray = queue.ToArray();

            Array.Resize(ref QueueArray, 5);

            txtQueue1.Text = (QueueArray[0] == 0) ? "" : QueueArray[0].ToString();
            txtQueue2.Text = (QueueArray[1] == 0) ? "" : QueueArray[1].ToString();
            txtQueue3.Text = (QueueArray[2] == 0) ? "" : QueueArray[2].ToString();
            txtQueue4.Text = (QueueArray[3] == 0) ? "" : QueueArray[3].ToString();
            txtQueue5.Text = (QueueArray[4] == 0) ? "" : QueueArray[4].ToString();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
