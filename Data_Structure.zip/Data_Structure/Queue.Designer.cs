﻿namespace Data_Structure
{
    partial class Queue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtQueue5 = new System.Windows.Forms.Label();
            this.txtQueue4 = new System.Windows.Forms.Label();
            this.txtQueue3 = new System.Windows.Forms.Label();
            this.txtQueue2 = new System.Windows.Forms.Label();
            this.txtQueue1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.EnqueueBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDequeue = new System.Windows.Forms.TextBox();
            this.DequeueBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtQueue5
            // 
            this.txtQueue5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtQueue5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtQueue5.Location = new System.Drawing.Point(110, 89);
            this.txtQueue5.Name = "txtQueue5";
            this.txtQueue5.Size = new System.Drawing.Size(97, 102);
            this.txtQueue5.TabIndex = 2;
            this.txtQueue5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtQueue4
            // 
            this.txtQueue4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtQueue4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtQueue4.Location = new System.Drawing.Point(230, 89);
            this.txtQueue4.Name = "txtQueue4";
            this.txtQueue4.Size = new System.Drawing.Size(97, 102);
            this.txtQueue4.TabIndex = 3;
            this.txtQueue4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtQueue3
            // 
            this.txtQueue3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtQueue3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtQueue3.Location = new System.Drawing.Point(350, 89);
            this.txtQueue3.Name = "txtQueue3";
            this.txtQueue3.Size = new System.Drawing.Size(97, 102);
            this.txtQueue3.TabIndex = 4;
            this.txtQueue3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtQueue2
            // 
            this.txtQueue2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtQueue2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtQueue2.Location = new System.Drawing.Point(470, 89);
            this.txtQueue2.Name = "txtQueue2";
            this.txtQueue2.Size = new System.Drawing.Size(97, 102);
            this.txtQueue2.TabIndex = 5;
            this.txtQueue2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtQueue1
            // 
            this.txtQueue1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtQueue1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txtQueue1.Location = new System.Drawing.Point(590, 89);
            this.txtQueue1.Name = "txtQueue1";
            this.txtQueue1.Size = new System.Drawing.Size(97, 102);
            this.txtQueue1.TabIndex = 6;
            this.txtQueue1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(59, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 19);
            this.label6.TabIndex = 18;
            this.label6.Text = "Queue";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(82, 311);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 12);
            this.label7.TabIndex = 21;
            this.label7.Text = "숫자 입력";
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(63, 326);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(92, 21);
            this.txtNum.TabIndex = 20;
            // 
            // EnqueueBtn
            // 
            this.EnqueueBtn.Location = new System.Drawing.Point(63, 353);
            this.EnqueueBtn.Name = "EnqueueBtn";
            this.EnqueueBtn.Size = new System.Drawing.Size(92, 25);
            this.EnqueueBtn.TabIndex = 19;
            this.EnqueueBtn.Text = "Enqueue";
            this.EnqueueBtn.UseVisualStyleBackColor = true;
            this.EnqueueBtn.Click += new System.EventHandler(this.EnqueueBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(630, 311);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 12);
            this.label8.TabIndex = 24;
            this.label8.Text = "Dequeue된 값";
            // 
            // txtDequeue
            // 
            this.txtDequeue.Location = new System.Drawing.Point(627, 326);
            this.txtDequeue.Name = "txtDequeue";
            this.txtDequeue.ReadOnly = true;
            this.txtDequeue.Size = new System.Drawing.Size(92, 21);
            this.txtDequeue.TabIndex = 23;
            // 
            // DequeueBtn
            // 
            this.DequeueBtn.Location = new System.Drawing.Point(627, 353);
            this.DequeueBtn.Name = "DequeueBtn";
            this.DequeueBtn.Size = new System.Drawing.Size(92, 25);
            this.DequeueBtn.TabIndex = 22;
            this.DequeueBtn.Text = "Dequeue";
            this.DequeueBtn.UseVisualStyleBackColor = true;
            this.DequeueBtn.Click += new System.EventHandler(this.DequeueBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(627, 24);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(92, 25);
            this.exitBtn.TabIndex = 25;
            this.exitBtn.Text = "나가기";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // Queue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtDequeue);
            this.Controls.Add(this.DequeueBtn);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.EnqueueBtn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtQueue1);
            this.Controls.Add(this.txtQueue2);
            this.Controls.Add(this.txtQueue3);
            this.Controls.Add(this.txtQueue4);
            this.Controls.Add(this.txtQueue5);
            this.Name = "Queue";
            this.Text = "Queue";
            this.Load += new System.EventHandler(this.Queue_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtQueue5;
        private System.Windows.Forms.Label txtQueue4;
        private System.Windows.Forms.Label txtQueue3;
        private System.Windows.Forms.Label txtQueue2;
        private System.Windows.Forms.Label txtQueue1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button EnqueueBtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDequeue;
        private System.Windows.Forms.Button DequeueBtn;
        private System.Windows.Forms.Button exitBtn;
    }
}