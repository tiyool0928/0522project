﻿namespace Data_Structure
{
    partial class LinkedList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.node1 = new System.Windows.Forms.Label();
            this.nullnode1 = new System.Windows.Forms.Label();
            this.Link4 = new System.Windows.Forms.Label();
            this.Link3 = new System.Windows.Forms.Label();
            this.Link5 = new System.Windows.Forms.Label();
            this.Link2 = new System.Windows.Forms.Label();
            this.Link1 = new System.Windows.Forms.Label();
            this.HeadNode = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtDequeue = new System.Windows.Forms.TextBox();
            this.DequeueBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNum = new System.Windows.Forms.TextBox();
            this.EnqueueBtn = new System.Windows.Forms.Button();
            this.n2addr = new System.Windows.Forms.Label();
            this.n3addr = new System.Windows.Forms.Label();
            this.node2 = new System.Windows.Forms.Label();
            this.n4addr = new System.Windows.Forms.Label();
            this.node3 = new System.Windows.Forms.Label();
            this.n5addr = new System.Windows.Forms.Label();
            this.node4 = new System.Windows.Forms.Label();
            this.nulladdr = new System.Windows.Forms.Label();
            this.node5 = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            this.nullnode2 = new System.Windows.Forms.Label();
            this.DeleteLabel = new System.Windows.Forms.Label();
            this.DeleteNum = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(76, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(104, 19);
            this.label6.TabIndex = 19;
            this.label6.Text = "Linked List";
            // 
            // node1
            // 
            this.node1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.node1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.node1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.node1.Location = new System.Drawing.Point(60, 177);
            this.node1.Name = "node1";
            this.node1.Size = new System.Drawing.Size(97, 30);
            this.node1.TabIndex = 27;
            this.node1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nullnode1
            // 
            this.nullnode1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nullnode1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nullnode1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.nullnode1.Location = new System.Drawing.Point(660, 148);
            this.nullnode1.Name = "nullnode1";
            this.nullnode1.Size = new System.Drawing.Size(97, 30);
            this.nullnode1.TabIndex = 28;
            this.nullnode1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Link4
            // 
            this.Link4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Link4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Link4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Link4.Location = new System.Drawing.Point(513, 177);
            this.Link4.Name = "Link4";
            this.Link4.Size = new System.Drawing.Size(40, 2);
            this.Link4.TabIndex = 29;
            this.Link4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Link3
            // 
            this.Link3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Link3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Link3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Link3.Location = new System.Drawing.Point(393, 177);
            this.Link3.Name = "Link3";
            this.Link3.Size = new System.Drawing.Size(40, 2);
            this.Link3.TabIndex = 30;
            this.Link3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Link5
            // 
            this.Link5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Link5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Link5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Link5.Location = new System.Drawing.Point(634, 177);
            this.Link5.Name = "Link5";
            this.Link5.Size = new System.Drawing.Size(30, 2);
            this.Link5.TabIndex = 31;
            this.Link5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Link2
            // 
            this.Link2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Link2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Link2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Link2.Location = new System.Drawing.Point(274, 177);
            this.Link2.Name = "Link2";
            this.Link2.Size = new System.Drawing.Size(40, 2);
            this.Link2.TabIndex = 32;
            this.Link2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Link1
            // 
            this.Link1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Link1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Link1.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.Link1.Location = new System.Drawing.Point(150, 177);
            this.Link1.Name = "Link1";
            this.Link1.Size = new System.Drawing.Size(40, 2);
            this.Link1.TabIndex = 33;
            this.Link1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HeadNode
            // 
            this.HeadNode.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.HeadNode.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.HeadNode.Location = new System.Drawing.Point(60, 108);
            this.HeadNode.Name = "HeadNode";
            this.HeadNode.Size = new System.Drawing.Size(97, 27);
            this.HeadNode.TabIndex = 34;
            this.HeadNode.Text = "Head";
            this.HeadNode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label14.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(110, 135);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(2, 16);
            this.label14.TabIndex = 35;
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(632, 313);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 12);
            this.label8.TabIndex = 41;
            this.label8.Text = "Dequeue된 값";
            // 
            // txtDequeue
            // 
            this.txtDequeue.Location = new System.Drawing.Point(629, 328);
            this.txtDequeue.Name = "txtDequeue";
            this.txtDequeue.Size = new System.Drawing.Size(92, 21);
            this.txtDequeue.TabIndex = 40;
            // 
            // DequeueBtn
            // 
            this.DequeueBtn.Location = new System.Drawing.Point(629, 355);
            this.DequeueBtn.Name = "DequeueBtn";
            this.DequeueBtn.Size = new System.Drawing.Size(92, 25);
            this.DequeueBtn.TabIndex = 39;
            this.DequeueBtn.Text = "Dequeue";
            this.DequeueBtn.UseVisualStyleBackColor = true;
            this.DequeueBtn.Click += new System.EventHandler(this.DequeueBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(84, 313);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 12);
            this.label1.TabIndex = 38;
            this.label1.Text = "숫자 입력";
            // 
            // txtNum
            // 
            this.txtNum.Location = new System.Drawing.Point(65, 328);
            this.txtNum.Name = "txtNum";
            this.txtNum.Size = new System.Drawing.Size(92, 21);
            this.txtNum.TabIndex = 37;
            // 
            // EnqueueBtn
            // 
            this.EnqueueBtn.Location = new System.Drawing.Point(65, 355);
            this.EnqueueBtn.Name = "EnqueueBtn";
            this.EnqueueBtn.Size = new System.Drawing.Size(92, 25);
            this.EnqueueBtn.TabIndex = 36;
            this.EnqueueBtn.Text = "Enqueue";
            this.EnqueueBtn.UseVisualStyleBackColor = true;
            this.EnqueueBtn.Click += new System.EventHandler(this.EnqueueBtn_Click);
            // 
            // n2addr
            // 
            this.n2addr.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.n2addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n2addr.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n2addr.Location = new System.Drawing.Point(60, 148);
            this.n2addr.Name = "n2addr";
            this.n2addr.Size = new System.Drawing.Size(97, 30);
            this.n2addr.TabIndex = 42;
            this.n2addr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // n3addr
            // 
            this.n3addr.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.n3addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n3addr.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n3addr.Location = new System.Drawing.Point(180, 148);
            this.n3addr.Name = "n3addr";
            this.n3addr.Size = new System.Drawing.Size(97, 30);
            this.n3addr.TabIndex = 43;
            this.n3addr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // node2
            // 
            this.node2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.node2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.node2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.node2.Location = new System.Drawing.Point(180, 177);
            this.node2.Name = "node2";
            this.node2.Size = new System.Drawing.Size(97, 30);
            this.node2.TabIndex = 44;
            this.node2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // n4addr
            // 
            this.n4addr.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.n4addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n4addr.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n4addr.Location = new System.Drawing.Point(300, 148);
            this.n4addr.Name = "n4addr";
            this.n4addr.Size = new System.Drawing.Size(97, 30);
            this.n4addr.TabIndex = 45;
            this.n4addr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // node3
            // 
            this.node3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.node3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.node3.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.node3.Location = new System.Drawing.Point(300, 177);
            this.node3.Name = "node3";
            this.node3.Size = new System.Drawing.Size(97, 30);
            this.node3.TabIndex = 46;
            this.node3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // n5addr
            // 
            this.n5addr.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.n5addr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n5addr.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.n5addr.Location = new System.Drawing.Point(420, 148);
            this.n5addr.Name = "n5addr";
            this.n5addr.Size = new System.Drawing.Size(97, 30);
            this.n5addr.TabIndex = 47;
            this.n5addr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // node4
            // 
            this.node4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.node4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.node4.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.node4.Location = new System.Drawing.Point(420, 177);
            this.node4.Name = "node4";
            this.node4.Size = new System.Drawing.Size(97, 30);
            this.node4.TabIndex = 48;
            this.node4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nulladdr
            // 
            this.nulladdr.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nulladdr.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nulladdr.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.nulladdr.Location = new System.Drawing.Point(540, 148);
            this.nulladdr.Name = "nulladdr";
            this.nulladdr.Size = new System.Drawing.Size(97, 30);
            this.nulladdr.TabIndex = 49;
            this.nulladdr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // node5
            // 
            this.node5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.node5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.node5.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.node5.Location = new System.Drawing.Point(540, 177);
            this.node5.Name = "node5";
            this.node5.Size = new System.Drawing.Size(97, 30);
            this.node5.TabIndex = 50;
            this.node5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(634, 40);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(92, 25);
            this.exitBtn.TabIndex = 51;
            this.exitBtn.Text = "나가기";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // nullnode2
            // 
            this.nullnode2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.nullnode2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nullnode2.Font = new System.Drawing.Font("굴림", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.nullnode2.Location = new System.Drawing.Point(660, 177);
            this.nullnode2.Name = "nullnode2";
            this.nullnode2.Size = new System.Drawing.Size(97, 30);
            this.nullnode2.TabIndex = 52;
            this.nullnode2.Text = "Null";
            this.nullnode2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DeleteLabel
            // 
            this.DeleteLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DeleteLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DeleteLabel.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.DeleteLabel.Location = new System.Drawing.Point(348, 295);
            this.DeleteLabel.Name = "DeleteLabel";
            this.DeleteLabel.Size = new System.Drawing.Size(97, 30);
            this.DeleteLabel.TabIndex = 53;
            this.DeleteLabel.Text = "삭제 된 노드";
            this.DeleteLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DeleteNum
            // 
            this.DeleteNum.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DeleteNum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.DeleteNum.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.DeleteNum.Location = new System.Drawing.Point(348, 322);
            this.DeleteNum.Name = "DeleteNum";
            this.DeleteNum.Size = new System.Drawing.Size(97, 30);
            this.DeleteNum.TabIndex = 54;
            this.DeleteNum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LinkedList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.DeleteNum);
            this.Controls.Add(this.DeleteLabel);
            this.Controls.Add(this.nullnode2);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.node5);
            this.Controls.Add(this.nulladdr);
            this.Controls.Add(this.node4);
            this.Controls.Add(this.n5addr);
            this.Controls.Add(this.node3);
            this.Controls.Add(this.n4addr);
            this.Controls.Add(this.node2);
            this.Controls.Add(this.n3addr);
            this.Controls.Add(this.n2addr);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtDequeue);
            this.Controls.Add(this.DequeueBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNum);
            this.Controls.Add(this.EnqueueBtn);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.HeadNode);
            this.Controls.Add(this.Link1);
            this.Controls.Add(this.Link2);
            this.Controls.Add(this.Link5);
            this.Controls.Add(this.Link3);
            this.Controls.Add(this.Link4);
            this.Controls.Add(this.nullnode1);
            this.Controls.Add(this.node1);
            this.Controls.Add(this.label6);
            this.Name = "LinkedList";
            this.Text = "LinkedList";
            this.Load += new System.EventHandler(this.LinkedList_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label node1;
        private System.Windows.Forms.Label nullnode1;
        private System.Windows.Forms.Label Link4;
        private System.Windows.Forms.Label Link3;
        private System.Windows.Forms.Label Link5;
        private System.Windows.Forms.Label Link2;
        private System.Windows.Forms.Label Link1;
        private System.Windows.Forms.Label HeadNode;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtDequeue;
        private System.Windows.Forms.Button DequeueBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNum;
        private System.Windows.Forms.Button EnqueueBtn;
        private System.Windows.Forms.Label n2addr;
        private System.Windows.Forms.Label n3addr;
        private System.Windows.Forms.Label node2;
        private System.Windows.Forms.Label n4addr;
        private System.Windows.Forms.Label node3;
        private System.Windows.Forms.Label n5addr;
        private System.Windows.Forms.Label node4;
        private System.Windows.Forms.Label nulladdr;
        private System.Windows.Forms.Label node5;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label nullnode2;
        private System.Windows.Forms.Label DeleteLabel;
        private System.Windows.Forms.Label DeleteNum;
    }
}