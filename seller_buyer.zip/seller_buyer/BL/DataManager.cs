﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace seller_buyer.BL
{
    class DataManager           //DB 연동
    {
        public static int BuyerLoginCheck(string id, string passwd)
        {
            string connstr = "server=localhost;user = root;password = cs1234;database = sellbuy";
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string sql = "select * from buyer where id = '" + id + "' && password = '" + passwd + "';";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                return 1;
            }
            catch (Exception)
            {
                return 2;
            }
            finally
            {
                conn.Close();
            }
        }

        public static int SellerLoginCheck(string id, string passwd)
        {
            string connstr = "server=localhost;user = root;password = cs1234;database = sellbuy";
            MySqlConnection conn = new MySqlConnection(connstr);

            try
            {
                conn.Open();
                string sql = "select * from seller where id = '" + id + "' && password = '" + passwd + "';";
                MySqlCommand command = new MySqlCommand(sql, conn);
                command.ExecuteNonQuery();
                return 1;
            }
            catch (Exception)
            {
                return 2;
            }
            finally
            {
                conn.Close();
            }
        }

        /*public static ObservableCollection<Seller> ShowAllSellers()
        {
            ObservableCollection<Seller> sellers = new ObservableCollection<Seller>();
            
            return sellers;
        }
        public  static void Buy(Buyer buyer, Seller seller, int count)
        {
            buyer.buy(seller, count);
        }*/
    }
}
