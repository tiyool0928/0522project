﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Navigation;
using seller_buyer.BL;
using seller_buyer.View;

namespace seller_buyer.ViewModel
{
    class IntroViewModel
    {
        public string ID { get; set; }
        public string Passwd { get; set; }
        public Command LoginCommand { get; set; }
        public bool Seller { get; set; }
        public bool Buyer { get; set; }

        public IntroViewModel()
        {
            ID = "";
            Passwd = "";
            LoginCommand = new Command(executeLogin, canexecuteLogin);
        }

        private bool canexecuteLogin(object arg)
        {
            return true;
        }

        private void executeLogin(object obj)
        {
            if(Buyer == true)
            {
                int result = DataManager.BuyerLoginCheck(ID, Passwd);
                if(result == 1)
                {
                    NavigationService.Navigate(new Uri("/View/BMenuView.xaml", UriKind.Relative));
                    LoginSession.LoginID = ID;
                    LoginSession.LoginPasswd = Passwd;
                }
                else if(result == 2)
                {
                    MessageBox.Show("DB연결에 실패하였습니다.");
                }
            }
            else if(Seller == true)
            {
                int result = DataManager.SellerLoginCheck(ID, Passwd);
                if(result == 1)
                {
                    NavigationService.Navigate(new Uri("/View/SMenuView.xaml", UriKind.Relative));
                    LoginSession.LoginID = ID;
                    LoginSession.LoginPasswd = Passwd;
                }
                else if(result == 2)
                {
                    MessageBox.Show("DB연결에 실패하였습니다.");
                }
            }
           
        }
    }
}
