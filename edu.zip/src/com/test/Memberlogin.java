package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Memberlogin extends HttpServlet {
	static Member[] members,obj,infor;
	String admin_id,admin_pwd;
	ServletContext sc;
	
	public void init(ServletConfig config) throws ServletException {
		//members = new Member[10];
		sc=config.getServletContext();
		admin_id = config.getInitParameter("adminId");
		admin_pwd = config.getInitParameter("adminPassword");
		//obj = new Member[10];
		
	}
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();

		String loginId = req.getParameter("id");
		String loginPasswd = req.getParameter("pw");
		int i;
		
		//Member newMember = (Member) sc.getAttribute("memberInfor");
		//Member infor = (Member)sc.getAttribute("memberInfor");
		sc.getAttribute("memberInfor");
		
		if(admin_id.equals(loginId) && admin_pwd.equals(loginPasswd)) {
			out.print("<html><head></head>");
			out.print("<body>�����ڴ� ȯ���մϴ�.</body>");
			out.print("</html>");
			out.close();
		}
		else if(admin_id.equals(loginId)) {
			out.print("<html><head></head>");
			out.print("<body>��й�ȣ�� Ʋ�Ƚ��ϴ�.</body>");
			out.print("</html>");
			out.close();
		}
		
		for(i=0; i<Member.count; i++) {
			/*if(members[i].getId().equals(loginId) && members[i].getPassword().equals(loginPasswd)) {*/
				if(obj[i].getId().equals(loginId) && obj[i].getPassword().equals(loginPasswd)) {
				out.print("<html><head></head>");
				out.print("<body>"+loginId+"������ �α��εǾ����ϴ�.</body>");
				out.print("</html>");
				out.close();
				break;
			}
			/*else if(members[i].getId().equals(loginId)) {*/
			else if(obj[i].getId().equals(loginId)) {
				out.print("<html><head></head>");
				out.print("<body>��й�ȣ�� Ʋ���ϴ�.</body>");
				out.print("</html>");
				out.close();
				break;
			}
		}
		if(i == Member.count) {
			out.print("<html><head></head>");
			out.print("<body>���̵� �������� �ʽ��ϴ�.</body>");
			out.print("</html>");
			out.close();
		}
	}
}
