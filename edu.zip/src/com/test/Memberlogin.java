package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Memberlogin extends HttpServlet{
	Member[] members;
	public void init(ServletConfig Config) throws ServletException{
		members = new Member[10];
	}
	public void doPost (HttpServletRequest req, HttpServletResponse resp) throws
	ServletException, IOException 
	{
		PrintWriter out = resp.getWriter();
		out.print(this.getInitParameter("adminId"));
		
		String Id = req.getParameter("id");
		String Password = req.getParameter("pw");
		
		resp.setContentType("text/html;charset=UTF-8");

	}
		public void doGet (HttpServletRequest req, HttpServletResponse resp) throws
		ServletException, IOException 
		{
			String id = req.getParameter("id");
			String password = req.getParameter("pw");
			
			/*members[Member.getCount()-1] = new Member(id,password);
		
			int i;
			
			for (i=1;i<=members.length;i++) {
				members[i] = new Member(id, password);
				id = req.getParameter("id");
				password = req.getParameter("password");
		}*/
			Member mb = new Member(id,password);
			
			resp.setContentType("text/html;charset=UTF-8");
			PrintWriter out = resp.getWriter();
			out.print("<html><head></head>");
			out.print("<body>"+mb.getId()+"�� ȸ�������� �����մϴ�!<br> ����� "+Member.getCount()+"��° ȸ���Դϴ�.</body>");
			out.print("</html>");
			out.close();
		}
	}
