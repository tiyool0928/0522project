package com.test;

public class Member {
	private String id;
	private String password;
	private static int count=0;
	
	public String getId() {
		return id;
	}
	public void SetId(String id) {
		this.id=id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Member (String id,String password) {
		this.id=id;
		this.password=password;
		count++;
	}
	static int getCount() {return count;}
	
}
