package com.test;

public class Member {
	private String id;
	private String password;
	static int count = 0;

	public Member(String tId, String tPwd) {
		id = tId;
		password = tPwd;
		count++;
	}
	
	public Member() {
		
	}
	
	public String getId() {
		return this.id;
	}

	public void SetId(String tId) {
		id = tId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String tPwd) {
		password = tPwd;
	}

	
}
