package com.test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Memberregister extends HttpServlet {
	Member[] members;
	String admin_id,admin_pwd;
	
	public void init(ServletConfig config) throws ServletException {
		members = new Member[10];
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String Id = req.getParameter("id");
		String Password = req.getParameter("pw");
		int i;
		
		Member newMember = new Member(Id,Password);
		members[Member.count-1] = newMember;
	
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		for(i=0; i<Member.count; i++) {
			if(members[i].getId().equals(Id)) {
				out.print("<html><head></head>");
				out.print("<body>�̹� �����ϴ� �����Դϴ�.</body>");
				out.print("</html>");
				out.close();
			}
			else {
				out.print("<html><head></head>");
				out.print("<body>" + newMember.getId() + "�� ȸ�������� �����մϴ�!<br> ����� " + Member.count + "��° ȸ���Դϴ�.</body>");
				out.print("</html>");
				out.close();
			}
		}
	}
}
