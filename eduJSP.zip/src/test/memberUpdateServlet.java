package test;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class memberUpdateServlet extends HttpServlet{
	
	ServletContext sc;
	
	public void init(ServletConfig config) throws ServletException
	{
		sc = config.getServletContext();
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException,IOException
	{
		String id=(String)req.getParameter("id");
		Member[] memberList = (Member[])sc.getAttribute("members");
		
		for(int i=0; i<Member.count; i++) 
		{
			if(memberList[i].getId().equals(id)) 
			{
				RequestDispatcher rd =req.getRequestDispatcher("memberUpdate2.jsp");
				rd.forward(req, resp);
				break;
			}
		}
	}

}
