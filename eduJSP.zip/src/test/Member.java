package test;

public class Member {
	private String id;
	private String password;
	private String name;
	static int count = 0;

	public Member(String tId, String tPwd, String tName) {
		id = tId;
		password = tPwd;
		name=tName;
		count++;
	}
	
	public String getId() {
		return this.id;
	}

	public void SetId(String tId) {
		id = tId;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String tPwd) {
		password = tPwd;
	}

	public String getName() {
		return this.name;
	}

	public void setname(String tName) {
		name = tName;
	}
	
}
