package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class LoginServlet extends HttpServlet{
	ServletContext sc;
	String adID;
	String adPwd;
	
	public void init(ServletConfig config) throws ServletException{
		sc = config.getServletContext();
		adID = sc.getInitParameter("adminId");
		adPwd = sc.getInitParameter("adminPassword");
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String inputId = req.getParameter("loginId");
		String inputPwd = req.getParameter("loginPasswd");
		ServletContext sc=req.getSession().getServletContext();
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		//out.print(inputId+""+inputPwd+":"+adID+""+adPwd);
		
		if(inputId.equals(adID) && inputPwd.equals(adPwd)) {
			
			req.setAttribute("id", inputId);
			RequestDispatcher rd = sc.getRequestDispatcher("/shop.jsp");
			rd.forward(req, resp);
		}
		else if(inputId.equals(adID)) {
			String errmsg = "Password is Wrong";
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/login.jsp");
			rd.forward(req, resp);
		}
		else {
			String errmsg = "ID is not exists";
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/login.jsp");
			rd.forward(req, resp);
		}
	}

}
