package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class LoginServlet extends HttpServlet{
	ServletContext sc;
	String adID;
	String adPwd;
	int i;
	
	public void init(ServletConfig config) throws ServletException{
		sc = config.getServletContext();
		adID = sc.getInitParameter("adminId");
		adPwd = sc.getInitParameter("adminPassword");
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException
	{
		String inputId = req.getParameter("loginId");
		String inputPwd = req.getParameter("loginPasswd");
		ServletContext sc=req.getSession().getServletContext();
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		//out.print(inputId+""+inputPwd+":"+adID+""+adPwd);
		
		if(inputId.equals(adID) && inputPwd.equals(adPwd)) {
			
			req.setAttribute("id", inputId);
			RequestDispatcher rd = sc.getRequestDispatcher("/admin.jsp");
			rd.forward(req, resp);
		}
		else if(inputId.equals(adID)) {
			String errmsg = "Admin's Password is Wrong";
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/login.jsp");
			rd.forward(req, resp);
		}
		else if (inputPwd.equals(adPwd)) {
			String errmsg = "Admin's ID is not exists";
			req.setAttribute("errorMsg",errmsg);
			RequestDispatcher rd = sc.getRequestDispatcher("/login.jsp");
			rd.forward(req, resp);
		}
		else {
			Member[] members = (Member[])sc.getAttribute("members");
			for(i=0; i<Member.count; i++)
			{
				if(members[i].getId().equals(inputId))
				{
					String errmsg = "Password is Wrong";
					req.setAttribute("errorMsg",errmsg);
					RequestDispatcher rd = sc.getRequestDispatcher("/login.jsp");
					rd.forward(req, resp);
				}
				else if(members[i].getPassword().equals(inputPwd))
				{
					
				}
			}
			if(i == Member.count) {
				String errmsg = "ID is not exists";
				req.setAttribute("errorMsg",errmsg);
				RequestDispatcher rd = sc.getRequestDispatcher("/login.jsp");
				rd.forward(req, resp);
			}
		}
	}

}
