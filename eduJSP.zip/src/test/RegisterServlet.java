package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet{
	static Member[] members;
	public void init(ServletConfig config) throws ServletException{
		members = new Member[10];
	}
	public void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException{
		String inputId = req.getParameter("registerId");
		String inputPwd = req.getParameter("registerPasswd");
		String inputName = req.getParameter("registerName");
		ServletContext sc = req.getSession().getServletContext();
		int i;
		
		Member newMember = new Member(inputId,inputPwd,inputName);
		members[Member.count-1] = newMember;
		
		String strNumber = Integer.toString(Member.count-1);
		sc.setAttribute(strNumber, newMember);
		
		resp.setContentType("text/html;charset=UTF-8");
		PrintWriter out = resp.getWriter();
		
		//out.print(""+inputId+inputPwd+inputName);
		
		for(i=0; i<Member.count-1; i++) {
			if(members[i].getId().equals(inputId)) {
					out.print("<html><head></head>");
					out.print("<body>�̹� �����ϴ� �����Դϴ�.</body>");
					out.print("</html>");
					out.close();
					Member.count--;
					break;
				}
		}
			out.print("<html><head></head>");
			out.print("<body>" + inputId + "�� ȸ�������� �����մϴ�!<br> ����� " + Member.count + "��° ȸ���Դϴ�.</body>");
			//out.print(""+inputId+inputPwd+inputName);
			out.print("</html>");
			out.close();
		}
		
	}
