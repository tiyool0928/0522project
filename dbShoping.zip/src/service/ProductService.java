package service;

import dao.ProductDAO;

public class ProductService {

	private static ProductService service = new ProductService();
	
	public ProductDAO dao = ProductDAO.getInstance();
	
	private ProductService() {
		
	}
	
	public static ProductService getInstance() {
		return service;
	}
	public void productInsert(String id,String pname) {
		dao.ProductInsert(id,pname);
	}
	public void productUpdate(String name) {
		dao.ProductUpdate(name);
	}
}

