package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MemberService;
import vo.Member;

public class MemberInsertController implements Controller{

	public void execute(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException,IOException{
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String pwd = req.getParameter("passwd");
		String phone = req.getParameter("phone");

		Member member = new Member();
		member.setId(id);
		member.setName(name);
		member.setEmail(email);
		member.setPasswd(pwd);
		member.setPhone(phone);
		
		//service
		MemberService service = MemberService.getInstance();
		service.memberInsert(member);
		
		//output
		req.setAttribute("id", id);
		HttpUtil.forward(req, resp, "main.jsp");
	}
}