package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.ProductService;
import vo.Product;

public class ProductUpdateController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = req.getSession();
		String id = (String)session.getAttribute("userid");
		//System.out.println(id+"");
		
		String pname =req.getParameter("item");
		Product item = new Product();
		item.setName(pname);
		
		ProductService pservice = ProductService.getInstance();
				pservice.productInsert(id,pname);
		
		ProductService service = ProductService.getInstance();
				service.productUpdate(pname);
				
				req.setAttribute("name", pname);
				HttpUtil.forward(req, resp, "back.jsp");
	}

}
