package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MemberService;
import vo.Member;

public class MemberUpdateController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id =req.getParameter("id");
		String passwd =req.getParameter("passwd");
		String name =req.getParameter("name");
		String email =req.getParameter("email");
		String phone =req.getParameter("phone");
		
		Member member = new Member();
		member.setId(id);
		member.setPasswd(passwd);
		member.setName(name);
		member.setEmail(email);
		member.setPhone(phone);
		
		MemberService service = MemberService.getInstance();
				service.memberUpdate(member);
				
				req.setAttribute("id", id);
				
				HttpUtil.forward(req, resp, "logout.jsp");
	}

}