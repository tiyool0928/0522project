package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MemberService;
import vo.Member;

public class MemberDeleteController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
			String id =req.getParameter("id");
			
			Member member = new Member();
			member.setId(id);
			
			MemberService service = MemberService.getInstance();
					service.memberDelete(id);
					
					req.setAttribute("id", id);
					
					HttpUtil.forward(req, resp, "main.jsp");
		}
	}
