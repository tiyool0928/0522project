package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.MemberService;
import service.ProductService;
import vo.Member;

public class MemberSearchController implements Controller{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String id = req.getParameter("id");
		
		String job = req.getParameter("job");
		
		String path=null;
		
		if(job.equals("delete"))
		path="/memberDelete.jsp";
		
		if(id.isEmpty())
		{
			req.setAttribute("error", "Enter ID");
			HttpUtil.forward(req, resp, path);
		}
		
		MemberService service = MemberService.getInstance();
		Member searchMember = service.memberSearch(id);
		
		req.setAttribute("member", searchMember);
		
		if(job.equals("search")) path="myinfor2.jsp";
		
		HttpSession session = req.getSession();
		session.setAttribute("tid", id);
		
		HttpUtil.forward(req, resp, path);
	}

}
