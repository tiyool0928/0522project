package dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import vo.Member;
import vo.Product;

public class ProductDAO {
	private static ProductDAO productDao = new ProductDAO();
	
	private ProductDAO() {
		
	}
	
	public static ProductDAO getInstance() {
		return productDao;
	}
	public Connection connect()
	{
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/yjcho?serverTimezone=UTC", "root", "cs1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public void ProductInsert(String id, String pname) {
		
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("insert into orders(id,pname) values(?,?)");

			pstmt.setString(1, id);
			pstmt.setString(2, pname);

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public void ProductUpdate(String pname)
	{
		Connection con = this.connect();
		
		try {
			PreparedStatement pstmt = con.prepareStatement("update product set count = count-1 where pname=?");

			pstmt.setString(1, pname);

			pstmt.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}