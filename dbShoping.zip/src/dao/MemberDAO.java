package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import vo.Member;

public class MemberDAO {
	private static MemberDAO memberDao = new MemberDAO();
	
	private MemberDAO() {
		
	}
	
	public static MemberDAO getInstance() {
		return memberDao;
	}
	public Connection connect()
	{
		Connection conn = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/yjcho?serverTimezone=UTC", "root", "cs1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public void memberInsert(Member member) {
		
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("insert into member values(?,?,?,?,?)");

			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getEmail());
			pstmt.setString(4, member.getPasswd());
			pstmt.setString(5, member.getPhone());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void memberDelete(String id)
	{
		Connection con = this.connect();
		
		try {
			PreparedStatement pstmt = con.prepareStatement("delete from member where id=?");

			pstmt.setString(1, id);
			
			pstmt.executeUpdate();
		} catch (Exception e) { 
			e.printStackTrace();
		}
	}
	public Member memberSearch(String id)
	{
		Member member = null;
		Connection con = this.connect();
		try {
			PreparedStatement pstmt = con.prepareStatement("select * from member where id = ?");
			pstmt.setString(1, id);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				member = new Member();
				member.setId(rs.getString(1));
				member.setName(rs.getString(2));
				member.setEmail(rs.getString(3));
				member.setPasswd(rs.getString(4));
				member.setPhone(rs.getString(5));
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return member;
	}
	public void memberUpdate(Member member)
	{
		Connection con = this.connect();
		
		try {
			PreparedStatement pstmt = con.prepareStatement("update member set name=?, email=?, passwd=?, phone=? where id=?");

			pstmt.setString(5, member.getId());
			pstmt.setString(1, member.getName());
			pstmt.setString(2, member.getEmail());
			pstmt.setString(3, member.getPasswd());
			pstmt.setString(4, member.getPhone());

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
